# BeatClip Kids

Offline, kid-friendly music video maker for Android 10+.

- Pick an MP3 (or make a beat): the app finds the tempo and beats on-device.
- Pick a world (11 animated scenes incl. Aurora and Glow Bokeh) and who dances: kids, bunnies, puppies, bears, pandas,
  penguins, frogs, foxes, cats, plus turtles, mermaids, flowers, fish, butterflies and stars.
- Dance styles: Disco, Cha-cha, Ballroom (with twirls), Line dance, Stepping, Rave (glow sticks), Pop & lock, Floss, or Mix.
- Live preview in time with the music: touch the screen and every character points at your finger. Your pointing can be
  recorded and replayed in the exported video.
- Song words appear on screen karaoke-style. Paste plain lines (spread across the song, snapped to beats)
  or load/paste a timed .lrc file.
- Colours adjustable. Quality popup (480p / 720p / 1080p) with Save (Movies) and Download.
- Fully offline. The only network code is KidPacks, and NetworkGate only opens it once every 30 days,
  behind a grown-up maths check, for a fixed list of safe picture topics (no free-text search).

## Build the APK
Push this folder to GitHub, open the Actions tab, run "Build APK", download the artifact.
Or open in Android Studio and Build > Build APK(s).

## Known risks (code has not been compiled or run on a device)
- First Gradle build may flag small compile errors; paste them back and they are quick to fix.
- Some phones' H.264 encoders reject certain sizes; the app retries at a 16-aligned size automatically.
- Beat detection assumes a steady beat; free-tempo or very quiet music may look off-beat.
- The monthly Wikimedia import has not been tested against the live service.

## Tests that were run (Python port of the beat detector, not the Kotlin build)
tools/*.py generate songs with known beats and check tempo/phase: steady 75-160 BPM, jitter, noise,
silent intro, kick-on-1&3 only, and a 100->124 BPM tempo change. All within ~10 ms. Run: python3 tools/regress.py
