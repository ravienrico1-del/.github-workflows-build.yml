import numpy as np
exec(open("tune.py").read().split('xs={}')[0])
tb=lambda b:60/(int(44100*60/b)/44100)
rows=[]
for b in (75,80,90,100,110,120,128,140,160):
    x,t=synth(b); rows.append((f"steady {b}",x,t))
x,t=synth(120,intro_silence=5.0); rows.append(("5 s silent intro",x,t))
rng=np.random.default_rng(1); x,t=synth(120); rows.append(("heavy noise",np.clip(x+rng.normal(0,0.08,len(x)),-1,1),t))
x,t=synth(120); beat=int(44100*60/120); s=x.copy()
for k in range(1,len(t),2): s[k*beat:k*beat+11025]*=0.05
rows.append(("kick on 1&3 only",s,t))
bad=0
for n,x,t in rows:
    be=analyze3(x,0.5,0.2); per=(be[-1]-be[0])/(len(be)-1)
    d=np.array([(be[np.argmin(abs(be-tt))]-tt)*1000 for tt in t if tt<=be[-1]])
    m=np.median(abs(d)); ok=m<30; bad+= (not ok)
    print(f"{n:20s} bpm {60/per:6.1f}  median|err| {m:4.0f} ms  {'OK' if ok else 'CHECK'}")
print("failures:",bad)
