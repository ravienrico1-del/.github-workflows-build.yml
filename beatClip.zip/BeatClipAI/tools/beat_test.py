import numpy as np, math, re, random

def synth(bpm, sr=44100, secs=60, intro_silence=0.0, jitter=0.0, seed=5):
    rng=np.random.default_rng(seed)
    beat=int(sr*60/bpm); n=sr*secs
    x=np.zeros(n); notes=[55.0,55.0,65.41,49.0]
    true=[]
    k=0
    while k*beat+int(intro_silence*sr) < n:
        start=int(intro_silence*sr)+k*beat + (int(rng.normal(0,jitter*sr)) if jitter else 0)
        true.append(start/sr)
        t=np.arange(min(beat, n-start))/sr
        if start<0 or start>=n: k+=1; continue
        kf=45+110*np.exp(-t*28); ph=np.cumsum(2*np.pi*kf/sr)
        kick=np.sin(ph)*np.exp(-t*9)*0.9
        seg=len(kick); x[start:start+seg]+=kick
        # off-beat hat + bass
        off=start+beat//2
        if off<n:
            to=np.arange(min(beat,n-off))/sr
            x[off:off+len(to)]+=(rng.random(len(to))*2-1)*np.exp(-to*70)*0.22 + np.sin(2*np.pi*notes[(k//2)%4]*(off/sr+to))*np.exp(-to*6)*0.35
        k+=1
    return np.clip(x*0.8,-1,1), np.array(true)

def analyze(x, sr=44100):
    hop=max(1,sr//50); hopsec=hop/sr
    alpha=min(max(2*math.pi*150/sr,0.001),0.5)
    lp=0.0; lv=[];bs=[]
    nh=len(x)//hop
    # one-pole low-pass exactly like the Kotlin loop
    y=np.empty(len(x)); 
    for i in range(0,len(x)):
        lp+=alpha*(x[i]-lp); y[i]=lp
    lvl=np.sqrt((x[:nh*hop].reshape(nh,hop)**2).mean(1)); bas=np.sqrt((y[:nh*hop].reshape(nh,hop)**2).mean(1))
    def norm(a):
        s=np.sort(a); ref=max(1e-6,s[min(int(len(s)*0.98),len(s)-1)]); return np.clip(a/ref,0,1)
    level=norm(lvl); bass=norm(bas); cnt=len(level)
    on=np.zeros(cnt); on[1:]=np.maximum(0,0.7*(bass[1:]-bass[:-1])+0.3*(level[1:]-level[:-1]))
    best=-1;bp=0.5/hopsec;bph=0;b=70.0
    while b<=170:
        per=60/b/hopsec
        for ph in range(math.ceil(per)):
            s=0;c=0;xx=float(ph)
            while xx<cnt-2:
                j=min(max(int(round(xx)),1),cnt-2); s+=max(on[j],on[j-1],on[j+1]); c+=1; xx+=per
            if c and s/c>best: best=s/c;bp=per;bph=ph
        b+=0.25
    if best<1e-4: bp=0.5/hopsec;bph=0
    beats=[];tk=float(bph);win=max(1,int(bp*0.2))
    while tk<cnt:
        c=min(max(int(round(tk)),0),cnt-1); bj=c;bv=-1
        for j in range(max(0,c-win),min(cnt-1,c+win)+1):
            if on[j]>bv: bv=on[j];bj=j
        if bv>0.05: tk+=0.3*(bj-tk)
        beats.append(tk*hopsec); tk+=bp
    return np.array(beats), (beats[-1]-beats[0])/(len(beats)-1)

def score(name,x,true,truebpm):
    beats,period=analyze(x)
    bpm=60/period
    # offset of each true beat to nearest detected beat (in ms); also look at first vs last quarter for drift
    d=np.array([ (beats[np.argmin(abs(beats-t))]-t)*1000 for t in true if t<=beats[-1]])
    q=len(d)//4
    print(f"{name:34s} true {truebpm:6.1f}  detected {bpm:6.1f}  median|err| {np.median(abs(d)):5.0f} ms  "
          f"p90 {np.percentile(abs(d),90):5.0f} ms  start {np.median(d[:q]):+5.0f}  end {np.median(d[-q:]):+5.0f}")
    return bpm, np.median(abs(d))

print("=== beat detection on generated songs (limit for 'on the beat' feel: ~60 ms) ===")
for bpm in (100,110,120,128):
    x,true=synth(bpm); tb=60/(int(44100*60/bpm)/44100)
    score(f"steady {bpm} bpm",x,true,tb)
x,true=synth(93,secs=90); score("steady 93 bpm, 90 s",x,true,60/(int(44100*60/93)/44100))
x,true=synth(120,intro_silence=5.0); score("120 bpm, 5 s silent intro",x,true,60/(int(44100*60/120)/44100))
x,true=synth(120,jitter=0.012); score("120 bpm, +-12 ms human jitter",x,true,60/(int(44100*60/120)/44100))
rng=np.random.default_rng(1); x,true=synth(120); x=np.clip(x+rng.normal(0,0.08,len(x)),-1,1); score("120 bpm, heavy noise",x,true,60/(int(44100*60/120)/44100))
x=np.zeros(44100*20); b,p=analyze(x); print(f"{'silence (must not crash)':34s} -> {60/p:.0f} bpm default, {len(b)} beats")

print("\n=== lyrics parser ===")
lineRe=re.compile(r'^\s*((?:\[\d{1,3}:\d{2}(?:[.:]\d{1,3})?\])+)\s*(.*)$'); tagRe=re.compile(r'\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]'); sec=re.compile(r'^\s*\[[^\]]*\]\s*$')
def parse(raw,dur):
    timed=[]
    for l in raw.split("\n"):
        m=lineRe.match(l)
        if not m: continue
        for t in tagRe.finditer(m.group(1)):
            fr=float("0."+t.group(3)) if t.group(3) else 0
            timed.append((int(t.group(1))*60+int(t.group(2))+fr,m.group(2).strip()))
    if timed:
        timed.sort(key=lambda a:a[0]); return [(s,(timed[i+1][0] if i+1<len(timed) else min(s+4,max(s+1,dur))),t) for i,(s,t) in enumerate(timed) if t]
    ts=[l.strip() for l in raw.split("\n") if l.strip() and not sec.match(l.strip())]
    return [(i*dur/len(ts),(i+1)*dur/len(ts),t) for i,t in enumerate(ts)]
print(parse("[00:05.50] Twinkle twinkle\n[00:09.00] little star\n[00:12] How I wonder",30))
print(parse("[Verse 1]\nRow row row your boat\nGently down the stream\n\n[Chorus]\nMerrily merrily",30))
print("windows line endings:",parse("[00:01.00] a\r\n[00:03.00] b\r\n",10))
