import numpy as np, math, itertools
exec(open("algo2.py").read().split('tb=lambda')[0])

def analyze3(x, pg, rg, win_frac=0.25):
    on,hopsec=features(x); cnt=len(on)
    best=-1;bp=0.5/hopsec;bph=0;b=70.0
    while b<=170:
        sc,ph=comb(on,60/b/hopsec)
        if sc>best: best=sc;bp=60/b/hopsec;bph=ph
        b+=0.25
    if 60/(bp*hopsec)<100:
        s2,p2=comb(on,bp/2)
        if s2>=0.92*best: bp=bp/2;bph=p2
    beats=[];tk=float(bph);per=bp;per0=bp;win=max(1,int(bp*win_frac))
    while tk<cnt:
        c=min(max(int(round(tk)),0),cnt-1);bj=c;bv=-1
        for j in range(max(0,c-win),min(cnt-1,c+win)+1):
            if on[j]>bv: bv=on[j];bj=j
        if bv>0.05:
            e=bj-tk; tk+=pg*e; per=min(max(per+rg*e,per0*0.75),per0*1.3)
        beats.append(tk*hopsec); tk+=per
    return np.array(beats)

def med(beats,true,sl=None):
    d=np.array([(beats[np.argmin(abs(beats-t))]-t)*1000 for t in true if t<=beats[-1]])
    return np.median(abs(d if sl is None else d[sl]))

xs={}
xs['j12']=synth(120,jitter=0.012); xs['j20']=synth(110,jitter=0.02,secs=120)
a,ta=synth(100,secs=30); b2,tb2=synth(124,secs=30)
xs['chg']=(np.concatenate([a,b2]),np.concatenate([ta,tb2+30])); n=len(ta)
xs['chg2']=(np.concatenate([synth(124,secs=30)[0],synth(100,secs=30)[0]]),np.concatenate([synth(124,secs=30)[1],synth(100,secs=30)[1]+30]))
print(" pg   rg   | jit12  jit20 | change up (2nd half)  change down (2nd half)")
for pg,rg in itertools.product((0.3,0.5),(0.04,0.1,0.2)):
    r=[]
    for k in ('j12','j20'):
        x,t=xs[k]; r.append(med(analyze3(x,pg,rg),t))
    x,t=xs['chg']; bu=med(analyze3(x,pg,rg),t,slice(n,None))
    x,t=xs['chg2']; bd=med(analyze3(x,pg,rg),t,slice(len(synth(124,secs=30)[1]),None))
    print(f"{pg:4.2f} {rg:5.2f} | {r[0]:5.0f} {r[1]:5.0f} | {bu:10.0f} ms {bd:16.0f} ms")
