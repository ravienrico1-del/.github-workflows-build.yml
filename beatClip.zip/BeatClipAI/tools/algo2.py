import numpy as np, math
src=open("beat_test.py").read().split('print("=== beat detection')[0]
exec(src)          # synth + old analyze (for features)

def features(x, sr=44100):
    hop=max(1,sr//50); hopsec=hop/sr; alpha=min(max(2*math.pi*150/sr,0.001),0.5)
    lp=0.0; nh=len(x)//hop; y=np.empty(len(x))
    for i in range(len(x)): lp+=alpha*(x[i]-lp); y[i]=lp
    lvl=np.sqrt((x[:nh*hop].reshape(nh,hop)**2).mean(1)); bas=np.sqrt((y[:nh*hop].reshape(nh,hop)**2).mean(1))
    def norm(a):
        s=np.sort(a); ref=max(1e-6,s[min(int(len(s)*0.98),len(s)-1)]); return np.clip(a/ref,0,1)
    level=norm(lvl); bass=norm(bas); on=np.zeros(nh); on[1:]=np.maximum(0,0.7*(bass[1:]-bass[:-1])+0.3*(level[1:]-level[:-1]))
    return on,hopsec

def comb(on,per,ph0=None):
    cnt=len(on); best=-1;bph=0
    for ph in range(math.ceil(per)):
        s=0;c=0;xx=float(ph)
        while xx<cnt-2:
            j=min(max(int(round(xx)),1),cnt-2); s+=max(on[j],on[j-1],on[j+1]); c+=1; xx+=per
        if c and s/c>best: best=s/c;bph=ph
    return best,bph

def analyze2(x, pll=True, dbl=True):
    on,hopsec=features(x); cnt=len(on)
    best=-1;bp=0.5/hopsec;bph=0;b=70.0
    while b<=170:
        sc,ph=comb(on,60/b/hopsec)
        if sc>best: best=sc;bp=60/b/hopsec;bph=ph
        b+=0.25
    if best<1e-4: bp=0.5/hopsec;bph=0
    elif dbl and 60/(bp*hopsec)<100:                   # NEW: half-tempo guard
        s2,p2=comb(on,bp/2)
        if s2>=0.92*best: bp=bp/2;bph=p2
    beats=[];tk=float(bph);per=bp;per0=bp;win=max(1,int(bp*0.25))
    while tk<cnt:
        c=min(max(int(round(tk)),0),cnt-1);bj=c;bv=-1
        for j in range(max(0,c-win),min(cnt-1,c+win)+1):
            if on[j]>bv: bv=on[j];bj=j
        if bv>0.05:
            err=bj-tk; tk+=0.3*err
            if pll: per=min(max(per+0.04*err,per0*0.75),per0*1.3)   # NEW: follow tempo changes
        beats.append(tk*hopsec); tk+=per
    return np.array(beats),(beats[-1]-beats[0])/(len(beats)-1)

def err(beats,true):
    return np.array([(beats[np.argmin(abs(beats-t))]-t)*1000 for t in true if t<=beats[-1]])

def case(name,x,true,truebpm,**kw):
    beats,per=analyze2(x,**kw); bpm=60/per; d=err(beats,true)
    # score both directions so half-tempo doesn't look 'wrong' by construction
    d2=np.array([(true[np.argmin(abs(true-b))]-b)*1000 for b in beats if b<=true[-1]])
    print(f"{name:36s} true {truebpm:6.1f} got {bpm:6.1f}  beats-vs-true median|err| {np.median(abs(d2)):4.0f} ms  true-vs-beats {np.median(abs(d)):4.0f} ms")

tb=lambda b:60/(int(44100*60/b)/44100)
print("=== NEW algorithm ===")
for b in (75,90,100,120,128,160):
    x,t=synth(b); case(f"steady {b}",x,t,tb(b))
x,t=synth(80); case("steady 80",x,t,tb(80))
x,t=synth(120,jitter=0.012); case("120 jitter 12 ms",x,t,tb(120))
rng=np.random.default_rng(1); x,t=synth(120); x=np.clip(x+rng.normal(0,0.08,len(x)),-1,1); case("120 heavy noise",x,t,tb(120))
x,t=synth(120,intro_silence=5.0); case("120 with 5 s silent intro",x,t,tb(120))
x,t=synth(110,jitter=0.02,secs=120); case("110, 20 ms jitter, 2 min",x,t,tb(110))
a,ta=synth(100,secs=30); b2,tb2=synth(124,secs=30); xx=np.concatenate([a,b2]); tt=np.concatenate([ta,tb2+30])
beats,per=analyze2(xx); d=err(beats,tt); n=len(ta)
print(f"{'tempo change 100->124 at 30 s':36s} median|err| first half {np.median(abs(d[:n])):4.0f} ms, second half {np.median(abs(d[n:])):4.0f} ms")
