package com.example.beatclipai

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.io.FileInputStream
import kotlin.math.max

/** Plays the decoded song so the live preview is in time with the music. */
class PcmPlayer(private val pcm: PcmAudio) {
    private var track: AudioTrack? = null
    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile var finished = false
        private set

    fun start() {
        val mask = if (pcm.channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(pcm.sampleRate).setChannelMask(mask).build()
        val minBuf = AudioTrack.getMinBufferSize(pcm.sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(fmt)
            .setBufferSizeInBytes(max(minBuf, pcm.sampleRate * pcm.channels))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        running = true
        finished = false
        t.play()
        thread = Thread {
            try {
                FileInputStream(pcm.file).use { ins ->
                    val buf = ByteArray(8192 * pcm.channels)
                    var left = pcm.frames * pcm.channels * 2L
                    while (running && left > 0) {
                        val n = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n <= 0) break
                        t.write(buf, 0, n)
                        left -= n
                    }
                }
            } catch (e: Exception) { }
            finished = true
        }.also { it.isDaemon = true; it.start() }
    }

    /** Seconds of the song that have actually come out of the speaker. */
    fun positionSec(): Float {
        val t = track ?: return 0f
        return t.playbackHeadPosition.toFloat() / pcm.sampleRate
    }

    fun stop() {
        running = false
        try { track?.pause(); track?.flush() } catch (e: Exception) { }
        try { thread?.join(300) } catch (e: Exception) { }
        try { track?.release() } catch (e: Exception) { }
        track = null
        thread = null
    }
}
