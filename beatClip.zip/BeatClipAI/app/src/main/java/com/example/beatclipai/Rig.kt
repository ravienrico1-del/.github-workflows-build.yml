package com.example.beatclipai

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class Species { KID, BUNNY, PUPPY, BEAR, PANDA, PENGUIN, FROG, FOX, CAT }

/** Where every body part is for one frame of one dance move. Arm angles are radians from straight down. */
internal class Pose {
    var dx = 0f; var jump = 0f; var lean = 0f; var tilt = 0f; var squash = 1f
    var aL1 = -0.3f; var aL2 = -0.3f; var aR1 = 0.3f; var aR2 = 0.3f
    var fLx = -0.10f; var fLy = 0f; var fRx = 0.10f; var fRy = 0f   // foot x offset and lift, in units of figure height
    var twirl = 0f; var sticks = false; var mouth = 0f; var dust = 0f
}

private fun ease(x: Float): Float { val v = x.coerceIn(0f, 1f); return v * v * (3f - 2f * v) }
private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

private val ROBOT = arrayOf(
    floatArrayOf(-1.57f, -1.57f, 0.35f, 0.35f, 8f),
    floatArrayOf(-1.57f, -3.1f, 1.57f, 3.1f, -8f),
    floatArrayOf(-2.9f, -2.9f, 2.9f, 2.9f, 0f),
    floatArrayOf(-2.3f, 0.4f, 2.3f, -0.4f, 6f)
)

internal fun poseFor(style: DanceStyle, m: Mo, mirror: Boolean): Pose {
    val P = Pose()
    val pi = PI.toFloat()
    val pos = m.pos
    val bar = ((pos % 4f) + 4f) % 4f
    val bi = bar.toInt()
    val bph = bar - bi
    val s = m.sway
    val kick = m.kick
    val air = m.air
    val lef = (m.beat % 2 == 0)

    fun stepFeet(h: Float) {
        val lift = h * sin(pi * m.ph)
        P.fLy = if (lef) lift else 0f
        P.fRy = if (lef) 0f else lift
    }

    when (style) {
        DanceStyle.DISCO, DanceStyle.MIX -> {
            val ur = (1f + s) / 2f
            P.aR1 = 0.9f + 1.7f * ur; P.aR2 = P.aR1
            P.aL1 = -(0.9f + 1.7f * (1f - ur)); P.aL2 = P.aL1
            P.dx = 0.04f * s; P.lean = -0.10f * s; P.jump = 0.04f * air; P.mouth = kick
            stepFeet(0.05f)
        }
        DanceStyle.CHACHA -> {
            P.dx = 0.05f * sin(pi * pos); P.lean = -0.12f * sin(pi * pos)
            if (bi < 2) {
                val lift = 0.045f * sin(pi * bph)
                P.fLy = if (bi == 0) lift else 0f
                P.fRy = if (bi == 1) lift else 0f
            } else {
                val sub = (bph * 3f).toInt()
                val lift = 0.035f * sin(pi * (bph * 3f - sub))
                val left = ((sub + bi) % 2 == 0)
                P.fLy = if (left) lift else 0f
                P.fRy = if (left) 0f else lift
                P.tilt = 7f * sin(4f * pi * pos)
            }
            val wv = 0.15f * sin(4f * pi * pos)
            P.aL1 = -0.8f - wv; P.aL2 = 0.95f; P.aR1 = 0.8f + wv; P.aR2 = -0.95f; P.mouth = 0.4f
        }
        DanceStyle.BALLROOM -> {
            val g = sin(pi * bar / 2f)
            P.aL1 = -1.85f; P.aL2 = -1.2f; P.aR1 = 0.9f; P.aR2 = -0.5f
            P.dx = 0.08f * g; P.jump = 0.03f * (0.5f - 0.5f * cos(pi * pos))
            P.tilt = 8f * g; P.lean = -0.06f * g
            P.fLx = -0.10f + 0.06f * g; P.fLy = 0.012f; P.fRx = 0.10f + 0.06f * g; P.fRy = 0.012f
            if (bar >= 2f) {
                P.twirl = 2f * pi * ease((bar - 2f) / 2f)
                P.aL1 = -2.4f; P.aL2 = -2.4f; P.aR1 = 2.4f; P.aR2 = 2.4f
                P.jump += 0.03f * sin(pi * (bar - 2f) / 2f)
            }
            P.mouth = 0.2f
        }
        DanceStyle.LINE -> {
            P.dx = 0.16f * sin(pi * bar / 2f)
            P.aL1 = -0.5f; P.aL2 = 0.8f; P.aR1 = 0.5f; P.aR2 = -0.8f
            stepFeet(0.05f)
            if (bi == 2) { P.dust = kick; P.fLy = 0.07f * (1f - bph); P.fRy = 0f; P.jump = 0.03f * air }
            if (bi == 3) { P.aL1 = -0.35f; P.aL2 = 1.25f; P.aR1 = 0.35f; P.aR2 = -1.25f; P.mouth = 1f }
        }
        DanceStyle.STEPPING -> {
            if (lef) { P.aL1 = -0.35f; P.aL2 = -0.25f; P.aR1 = 0.35f; P.aR2 = 0.25f }
            else { P.aL1 = -0.75f; P.aL2 = 1.15f; P.aR1 = 0.75f; P.aR2 = -1.15f }
            P.fLy = if (lef) 0.075f * (1f - m.ph) else 0f
            P.fRy = if (lef) 0f else 0.075f * (1f - m.ph)
            P.dust = kick; P.squash = 1f - 0.1f * kick; P.dx = 0.03f * s; P.mouth = kick
        }
        DanceStyle.RAVE -> {
            val f = sin(4f * pi * pos)
            P.jump = 0.075f * abs(sin(2f * pi * pos))
            P.aL1 = -(2.7f + 0.2f * f); P.aL2 = P.aL1 - 0.5f * f
            P.aR1 = 2.7f + 0.2f * f; P.aR2 = P.aR1 + 0.5f * f
            P.tilt = 8f * f; P.sticks = true; P.mouth = 1f; P.fLy = 0.02f; P.fRy = 0.02f
        }
        DanceStyle.ROBOT -> {
            val q0 = floor(pos * 2f).toInt()
            val q = ((q0 % 4) + 4) % 4
            val pr = ((q0 - 1) % 4 + 4) % 4
            val f2 = pos * 2f - floor(pos * 2f)
            val k = ease(f2 / 0.15f)
            val a = ROBOT[pr]
            val b = ROBOT[q]
            P.aL1 = lerp(a[0], b[0], k); P.aL2 = lerp(a[1], b[1], k)
            P.aR1 = lerp(a[2], b[2], k); P.aR2 = lerp(a[3], b[3], k)
            P.tilt = lerp(a[4], b[4], k)
        }
        DanceStyle.FLOSS -> {
            P.aL1 = -0.25f + 0.75f * s; P.aL2 = P.aL1
            P.aR1 = 0.25f + 0.75f * s; P.aR2 = P.aR1
            P.dx = -0.07f * s; P.lean = 0.12f * s; P.jump = 0.03f * air; P.mouth = 0.5f
            stepFeet(0.03f)
        }
    }

    if (mirror) {
        P.dx = -P.dx; P.lean = -P.lean; P.tilt = -P.tilt
        val l1 = -P.aR1; val l2 = -P.aR2; val r1 = -P.aL1; val r2 = -P.aL2
        P.aL1 = l1; P.aL2 = l2; P.aR1 = r1; P.aR2 = r2
        val nlx = -P.fRx; val nly = P.fRy; val nrx = -P.fLx; val nry = P.fLy
        P.fLx = nlx; P.fLy = nly; P.fRx = nrx; P.fRy = nry
    }
    return P
}

private val KID_SKINS = intArrayOf(0xFFFFDBB4.toInt(), 0xFFF1C27D.toInt(), 0xFFC68642.toInt(), 0xFF8D5524.toInt(), 0xFFFFE0C2.toInt())
private val KID_HAIRS = intArrayOf(0xFF3B2314.toInt(), 0xFF1C1C1C.toInt(), 0xFFB5651D.toInt(), 0xFFE8B84A.toInt(), 0xFFD2503C.toInt())

private fun furs(sp: Species): IntArray = when (sp) {
    Species.BUNNY -> intArrayOf(0xFFF7F2F2.toInt(), 0xFFD9D4D8.toInt(), 0xFFE9C9A0.toInt(), 0xFFFAD1DC.toInt())
    Species.PUPPY -> intArrayOf(0xFFE8B87A.toInt(), 0xFFF5E6CC.toInt(), 0xFFB5834E.toInt(), 0xFFD9D4D8.toInt())
    Species.BEAR -> intArrayOf(0xFFB07A4F.toInt(), 0xFF8A5A3A.toInt(), 0xFFD9A066.toInt(), 0xFF6F4E37.toInt())
    Species.PANDA -> intArrayOf(0xFFFFFFFF.toInt())
    Species.PENGUIN -> intArrayOf(0xFF2E3A5E.toInt())
    Species.FROG -> intArrayOf(0xFF7BD66B.toInt(), 0xFF5BC0A0.toInt(), 0xFF9BE05B.toInt())
    Species.FOX -> intArrayOf(0xFFF08A3C.toInt(), 0xFFE06A2C.toInt())
    Species.CAT -> intArrayOf(0xFFE8E0F0.toInt(), 0xFFF0A65B.toInt(), 0xFF9AA0B5.toInt())
    Species.KID -> intArrayOf(0xFFFFDBB4.toInt())
}

/** One dancing character: a kid or an animal, posed by [P], optionally pointing at [tgt] (pixels). */
internal fun SceneRenderer.drawRig(c: Canvas, sp: Species, cx: Float, gy: Float, sz: Float, m: Mo, P: Pose, idx: Int, tgt: FloatArray?) {
    val kid = sp == Species.KID
    val ol = sz * 0.014f
    val fl = furs(sp)
    val fur = if (kid) KID_SKINS[idx % 5] else fl[idx % fl.size]
    val shirt = when (idx % 3) { 0 -> prim; 1 -> sec; else -> acc }
    val hair = KID_HAIRS[(idx * 2 + 1) % 5]
    val dark = 0xFF2B2B33.toInt()
    val orange = 0xFFFF9F43.toInt()
    val skin = fur
    val legc = if (kid) mix(when (idx % 3) { 0 -> sec; 1 -> acc; else -> prim }, 0xFF1B1B3A.toInt(), .45f)
        else if (sp == Species.PANDA) dark else if (sp == Species.PENGUIN) orange else fur
    val armc = if (kid) shirt else if (sp == Species.PANDA) dark else fur
    val bodyc = if (kid) shirt else fur
    val belly: Int? = when (sp) {
        Species.BUNNY -> 0xFFFFE4EC.toInt(); Species.PUPPY -> 0xFFFFF3E0.toInt(); Species.BEAR -> 0xFFEBCB9A.toInt()
        Species.PANDA -> Color.WHITE; Species.PENGUIN -> Color.WHITE; Species.FROG -> 0xFFF3FFD6.toInt()
        Species.FOX -> 0xFFFFF3E0.toInt(); Species.CAT -> Color.WHITE; else -> null
    }
    val air = m.air
    val sway = m.sway
    val sway2 = m.sway2

    c.save()
    if (P.twirl != 0f) c.scale(max(0.35f, abs(cos(P.twirl))), 1f, cx, gy)
    val sk = 1f - 0.3f * min(1f, P.jump * 8f)
    c.drawOval(RectF(cx - sz * 0.2f * sk, gy - sz * 0.025f, cx + sz * 0.2f * sk, gy + sz * 0.025f), fillP(Color.BLACK, .22f))
    val legL = sz * 0.27f * P.squash
    val jump = P.jump * sz
    val hx = cx + P.dx * sz
    val hy = gy - legL - jump

    // legs and shoes (dust puffs on stomps)
    for (k in 0..1) {
        val fx = if (k == 0) cx + P.fLx * sz + P.dx * sz * 0.6f else cx + P.fRx * sz + P.dx * sz * 0.6f
        val fy = gy - jump * 0.7f - (if (k == 0) P.fLy else P.fRy) * sz
        limb(c, hx + (k * 2 - 1) * sz * 0.05f, hy, fx, fy, sz * 0.075f, legc, ol)
        val shoe = if (kid) Color.WHITE else if (sp == Species.PENGUIN) orange else mix(if (sp == Species.PANDA) dark else fur, Color.WHITE, .25f)
        blob(c, RectF(fx - sz * 0.07f, fy - sz * 0.035f, fx + sz * 0.09f, fy + sz * 0.03f), shoe, ol)
        if (P.dust > 0.4f && fy > gy - sz * 0.02f) {
            for (q in 0..2) c.drawCircle(fx + (q - 1) * sz * 0.05f, gy - sz * 0.01f - q * sz * 0.01f, sz * 0.02f * P.dust, fillP(Color.WHITE, .6f))
        }
    }

    // tails
    if (sp == Species.FOX || sp == Species.CAT || sp == Species.PUPPY || sp == Species.BUNNY) {
        val tx = hx + sz * 0.17f + sway2 * sz * 0.07f
        val ty = hy - sz * (if (sp != Species.FOX) 0.04f else 0.12f)
        if (sp == Species.BUNNY) {
            blob(c, RectF(tx - sz * 0.05f, ty - sz * 0.05f, tx + sz * 0.05f, ty + sz * 0.05f), Color.WHITE, ol)
        } else {
            val tw = sz * (if (sp == Species.FOX) 0.11f else 0.06f)
            path.reset(); path.moveTo(hx + sz * 0.1f, hy - sz * 0.02f); path.quadTo(hx + sz * 0.28f, hy + sz * 0.02f, tx + sz * 0.1f, ty - sz * 0.14f)
            c.drawPath(path, strokeP(OUT, tw + ol * 2f)); c.drawPath(path, strokeP(fur, tw))
            if (sp == Species.FOX) c.drawCircle(tx + sz * 0.1f, ty - sz * 0.14f, sz * 0.05f, fillP(Color.WHITE))
        }
    }

    // torso, belly, scarf
    c.save(); c.rotate(Math.toDegrees(P.lean.toDouble()).toFloat(), hx, hy)
    val torsoTop = hy - sz * 0.27f * P.squash
    if (sp == Species.PENGUIN) blob(c, RectF(hx - sz * 0.14f, torsoTop - sz * 0.02f, hx + sz * 0.14f, hy + sz * 0.04f), bodyc, ol)
    else blob(c, RectF(hx - sz * 0.115f, torsoTop, hx + sz * 0.115f, hy + sz * 0.03f), bodyc, ol)
    if (belly != null) c.drawOval(RectF(hx - sz * 0.075f, torsoTop + sz * 0.05f, hx + sz * 0.075f, hy), fillP(belly))
    else if (kid) c.drawRect(hx - sz * 0.10f, hy - sz * 0.07f, hx + sz * 0.10f, hy - sz * 0.03f, fillP(mix(shirt, Color.WHITE, .45f), .8f))
    if (sp != Species.KID && sp != Species.PENGUIN) {
        val sc = when ((idx + 1) % 3) { 0 -> prim; 1 -> sec; else -> acc }
        val rc = RectF(hx - sz * 0.10f, torsoTop - sz * 0.005f, hx + sz * 0.10f, torsoTop + sz * 0.04f)
        c.drawRoundRect(rc, sz * 0.02f, sz * 0.02f, fillP(sc)); c.drawRoundRect(rc, sz * 0.02f, sz * 0.02f, strokeP(OUT, ol * .8f))
    }

    // arms (the one nearest the touch points at it)
    val l1 = sz * 0.13f
    val l2 = sz * 0.12f
    val shY = torsoTop + sz * 0.05f
    val ptSide = if (tgt == null) 0 else if (tgt[0] < hx) -1 else 1
    for (side in intArrayOf(-1, 1)) {
        val sx = hx + side * sz * 0.10f
        var a1 = if (side < 0) P.aL1 else P.aR1
        var a2 = if (side < 0) P.aL2 else P.aR2
        val pointing = tgt != null && side == ptSide
        if (pointing && tgt != null) {
            a1 = atan2(tgt[0] - sx, tgt[1] - shY)
            a2 = a1 + 0.12f * sin(4f * PI.toFloat() * m.pos)
        }
        val ex = sx + sin(a1) * l1
        val ey = shY + cos(a1) * l1
        val fx = ex + sin(a2) * l2
        val fy = ey + cos(a2) * l2
        limb(c, sx, shY, ex, ey, sz * 0.06f, armc, ol)
        val foreCol = if (kid || sp == Species.PENGUIN) skin else armc
        limb(c, ex, ey, fx, fy, sz * 0.05f, foreCol, ol)
        if (P.sticks) {
            val col = when ((idx + (if (side > 0) 1 else 0)) % 3) { 0 -> acc; 1 -> prim; else -> sec }
            val dX = sin(a2) * sz * 0.16f
            val dY = cos(a2) * sz * 0.16f
            c.drawLine(fx, fy, fx + dX, fy + dY, strokeP(col, sz * 0.07f, .35f))
            c.drawLine(fx, fy, fx + dX, fy + dY, strokeP(Color.WHITE, sz * 0.028f))
        }
        val handCol = if (kid || sp == Species.PENGUIN) skin else if (sp == Species.PANDA) armc else mix(armc, Color.WHITE, .2f)
        blob(c, RectF(fx - sz * 0.038f, fy - sz * 0.038f, fx + sz * 0.038f, fy + sz * 0.038f), handCol, ol)
        if (pointing) {
            val dX = sin(a2) * sz * 0.09f
            val dY = cos(a2) * sz * 0.09f
            c.drawLine(fx, fy, fx + dX, fy + dY, strokeP(OUT, sz * 0.032f + ol * 2f))
            c.drawLine(fx, fy, fx + dX, fy + dY, strokeP(if (kid) skin else armc, sz * 0.032f))
        }
    }

    // head
    val r = sz * 0.135f
    val ncx = hx
    val ncy = torsoTop - r * 0.82f
    var look = sway * 0.6f
    var tilt = P.tilt + sway2 * 5f
    if (tgt != null) {
        look = ((tgt[0] - ncx) / (sz * 0.9f)).coerceIn(-1f, 1f)
        tilt = tilt * 0.3f + look * 7f
    }
    val mo = if (tgt == null) P.mouth else max(P.mouth, 0.5f)
    c.save(); c.rotate(tilt, hx, torsoTop + sz * 0.02f)
    val inner = 0xFFFFB6C1.toInt()
    if (sp == Species.KID) {
        val style = idx % 3
        if (style == 0) blob(c, RectF(ncx - r * 0.38f, ncy - r * 1.55f, ncx + r * 0.38f, ncy - r * 0.85f), hair, ol)
        if (style == 1) {
            for (side in intArrayOf(-1, 1)) {
                val px = ncx + side * r * 1.05f + sway2 * sz * 0.03f
                blob(c, RectF(px - r * 0.34f, ncy - r * 0.1f, px + r * 0.34f, ncy + r * 0.95f), hair, ol)
            }
        }
        blob(c, RectF(ncx - r, ncy - r, ncx + r, ncy + r), skin, ol)
        val cap = RectF(ncx - r * 1.04f, ncy - r * 1.04f, ncx + r * 1.04f, ncy + r * 1.04f)
        c.drawArc(cap, 195f, 150f, true, fillP(hair)); c.drawArc(cap, 195f, 150f, false, strokeP(OUT, ol))
        face(c, ncx, ncy + r * 0.05f, r, m.blink, look, mo)
    } else {
        if (sp == Species.BUNNY) {
            for (side in intArrayOf(-1, 1)) {
                val flop = sway2 * 0.12f * side
                c.save(); c.translate(ncx + side * r * 0.45f, ncy - r * 0.7f); c.rotate(Math.toDegrees(flop.toDouble()).toFloat() + side * 6f)
                blob(c, RectF(-r * 0.27f, -r * 1.75f, r * 0.27f, 0f), fur, ol)
                c.drawOval(RectF(-r * 0.14f, -r * 1.55f, r * 0.14f, -r * 0.2f), fillP(inner)); c.restore()
            }
        }
        if (sp == Species.PUPPY) {
            for (side in intArrayOf(-1, 1)) {
                c.save(); c.translate(ncx + side * r * 0.95f, ncy - r * 0.55f); c.rotate(side * (18f + sway2 * 8f))
                blob(c, RectF(-r * 0.3f, -r * 0.1f, r * 0.3f, r * 1.3f), mix(fur, OUT, .3f), ol); c.restore()
            }
        }
        if (sp == Species.BEAR || sp == Species.PANDA) {
            for (side in intArrayOf(-1, 1)) {
                blob(c, RectF(ncx + side * r * 0.78f - r * 0.28f, ncy - r * 1.1f, ncx + side * r * 0.78f + r * 0.28f, ncy - r * 0.55f), if (sp == Species.PANDA) dark else fur, ol)
            }
        }
        if (sp == Species.FOX || sp == Species.CAT) {
            for (side in intArrayOf(-1, 1)) {
                path.reset(); path.moveTo(ncx + side * r * 0.95f, ncy - r * 0.1f); path.lineTo(ncx + side * r * 0.8f, ncy - r * 1.45f); path.lineTo(ncx + side * r * 0.1f, ncy - r * 0.85f); path.close()
                c.drawPath(path, fillP(fur)); c.drawPath(path, strokeP(OUT, ol))
                if (sp == Species.FOX) {
                    path.reset(); path.moveTo(ncx + side * r * 0.8f, ncy - r * 1.45f); path.lineTo(ncx + side * r * 0.86f, ncy - r * 1.02f); path.lineTo(ncx + side * r * 0.5f, ncy - r * 1.05f); path.close()
                    c.drawPath(path, fillP(0xFF3B2314.toInt()))
                } else {
                    path.reset(); path.moveTo(ncx + side * r * 0.8f, ncy - r * 0.35f); path.lineTo(ncx + side * r * 0.74f, ncy - r * 1.05f); path.lineTo(ncx + side * r * 0.35f, ncy - r * 0.75f); path.close()
                    c.drawPath(path, fillP(inner))
                }
            }
        }
        if (sp == Species.FROG) {
            for (side in intArrayOf(-1, 1)) {
                val ex = ncx + side * r * 0.55f
                val ey = ncy - r * 0.95f
                blob(c, RectF(ex - r * 0.36f, ey - r * 0.36f, ex + r * 0.36f, ey + r * 0.36f), fur, ol)
                c.drawCircle(ex, ey, r * 0.24f, fillP(Color.WHITE))
                c.drawCircle(ex + look * r * 0.08f, ey + r * 0.02f, r * 0.14f, fillP(OUT))
                c.drawCircle(ex + r * 0.04f, ey - r * 0.05f, r * 0.05f, fillP(Color.WHITE))
            }
        }
        val hr = if (sp == Species.FROG || sp == Species.PENGUIN) r * 1.08f else r
        val hv = if (sp == Species.BEAR) r * 0.95f else r * 0.92f
        blob(c, RectF(ncx - hr, ncy - hv, ncx + hr, ncy + hv), fur, ol)
        if (sp == Species.PANDA) {
            for (side in intArrayOf(-1, 1)) {
                c.save(); c.translate(ncx + side * r * 0.4f, ncy - r * 0.05f); c.rotate(side * 25f)
                c.drawOval(RectF(-r * 0.2f, -r * 0.3f, r * 0.2f, r * 0.3f), fillP(dark)); c.restore()
            }
        }
        if (sp == Species.BEAR || sp == Species.PUPPY || sp == Species.BUNNY || sp == Species.FOX || sp == Species.PANDA) {
            c.drawOval(RectF(ncx - r * 0.45f, ncy + r * 0.05f, ncx + r * 0.45f, ncy + r * 0.7f), fillP(if (sp == Species.BUNNY) 0xFFFFF0F4.toInt() else 0xFFFFF3E0.toInt()))
        }
        if (sp == Species.PENGUIN) c.drawOval(RectF(ncx - r * 0.65f, ncy - r * 0.2f, ncx + r * 0.65f, ncy + r * 0.8f), fillP(Color.WHITE))
        face(c, ncx, ncy + r * 0.05f, r, m.blink, look, mo, sp != Species.PANDA)
        val nose: Int? = when (sp) {
            Species.BUNNY -> 0xFFFF8FA3.toInt(); Species.PUPPY -> OUT; Species.BEAR -> OUT; Species.PANDA -> dark
            Species.CAT -> 0xFFFF6B8B.toInt(); Species.FOX -> OUT; else -> null
        }
        if (nose != null) c.drawOval(RectF(ncx - r * 0.12f, ncy + r * 0.18f, ncx + r * 0.12f, ncy + r * 0.34f), fillP(nose))
        if (sp == Species.PENGUIN) {
            path.reset(); path.moveTo(ncx - r * 0.2f, ncy + r * 0.2f); path.lineTo(ncx + r * 0.2f, ncy + r * 0.2f); path.lineTo(ncx, ncy + r * 0.45f); path.close()
            c.drawPath(path, fillP(orange)); c.drawPath(path, strokeP(OUT, ol * .8f))
        }
        if (sp == Species.BUNNY && mo < 0.2f) {
            val tooth = RectF(ncx - r * 0.1f, ncy + r * 0.42f, ncx + r * 0.1f, ncy + r * 0.56f)
            c.drawRect(tooth, fillP(Color.WHITE)); c.drawRect(tooth, strokeP(OUT, ol * .6f))
        }
        if (sp == Species.PUPPY && mo > 0.3f) {
            c.drawOval(RectF(ncx - r * 0.1f, ncy + r * 0.55f, ncx + r * 0.1f, ncy + r * 0.8f), fillP(0xFFFF6B8B.toInt()))
        }
        if (sp == Species.CAT) {
            for (side in intArrayOf(-1, 1)) for (k in -1..1)
                c.drawLine(ncx + side * r * 0.75f, ncy + r * 0.38f, ncx + side * r * 1.4f, ncy + r * 0.3f + k * r * 0.2f, strokeP(OUT, r * 0.03f, .8f))
        }
    }
    c.restore(); c.restore(); c.restore()
}
