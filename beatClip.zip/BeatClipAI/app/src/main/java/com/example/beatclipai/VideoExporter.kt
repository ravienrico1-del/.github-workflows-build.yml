package com.example.beatclipai

import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import kotlin.math.ceil
import kotlin.math.min

class RenderParams(
    val pcm: PcmAudio,
    val beats: BeatMap,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val fps: Int,
    val videoBitrate: Int,
    val scene: Scene
)

internal class Sample(val data: ByteArray, val ptsUs: Long, val flags: Int)
internal class AacTrack(val format: MediaFormat, val samples: List<Sample>)

object VideoExporter {

    private fun readFully(ins: FileInputStream, buf: ByteArray): Int {
        var off = 0
        while (off < buf.size) {
            val r = ins.read(buf, off, buf.size - off)
            if (r <= 0) break
            off += r
        }
        return off
    }

    private fun encodeAudio(pcm: PcmAudio, durationMs: Long): AacTrack {
        val sr = pcm.sampleRate
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sr, pcm.channels)
        fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 shl 16)
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
        val bytesPerFrame = pcm.channels * 2
        val maxFrames = min(pcm.frames, durationMs * sr / 1000L)
        val info = MediaCodec.BufferInfo()
        val out = ArrayList<Sample>()
        var outFormat: MediaFormat? = null
        var fed = 0L
        var inDone = false
        var outDone = false
        val ins = FileInputStream(pcm.file)
        try {
            while (!outDone) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)!!
                        buf.clear()
                        val remaining = maxFrames - fed
                        if (remaining <= 0) {
                            codec.queueInputBuffer(i, 0, 0, fed * 1_000_000L / sr, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            val framesNow = min(remaining, (min(buf.capacity(), 16384) / bytesPerFrame).toLong()).toInt()
                            val bytes = ByteArray(framesNow * bytesPerFrame)
                            val n = readFully(ins, bytes)
                            if (n <= 0) {
                                codec.queueInputBuffer(i, 0, 0, fed * 1_000_000L / sr, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inDone = true
                            } else {
                                buf.put(bytes, 0, n)
                                codec.queueInputBuffer(i, 0, n, fed * 1_000_000L / sr, 0)
                                fed += n / bytesPerFrame
                            }
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    outFormat = codec.outputFormat
                } else if (o >= 0) {
                    val ob = codec.getOutputBuffer(o)!!
                    if (info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        val d = ByteArray(info.size)
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.get(d)
                        out.add(Sample(d, info.presentationTimeUs, info.flags))
                    }
                    codec.releaseOutputBuffer(o, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                }
            }
        } finally {
            ins.close()
            try { codec.stop() } catch (e: Exception) { }
            codec.release()
        }
        return AacTrack(requireNotNull(outFormat) { "audio encoder produced no format" }, out)
    }

    private fun fillImage(img: Image, px: IntArray, w: Int, h: Int, row: ByteArray) {
        val yp = img.planes[0]
        val up = img.planes[1]
        val vp = img.planes[2]
        val yb = yp.buffer
        val ub = up.buffer
        val vb = vp.buffer
        for (y in 0 until h) {
            val base = y * w
            for (x in 0 until w) {
                val c = px[base + x]
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val b = c and 255
                row[x] = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte()
            }
            yb.position(y * yp.rowStride)
            yb.put(row, 0, w)
        }
        for (y in 0 until h / 2) {
            for (x in 0 until w / 2) {
                var r = 0
                var g = 0
                var b = 0
                for (dy in 0..1) {
                    for (dx in 0..1) {
                        val c = px[(2 * y + dy) * w + 2 * x + dx]
                        r += (c shr 16) and 255
                        g += (c shr 8) and 255
                        b += c and 255
                    }
                }
                r = r shr 2; g = g shr 2; b = b shr 2
                val u = (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).coerceIn(0, 255)
                val v = (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).coerceIn(0, 255)
                ub.put(y * up.rowStride + x * up.pixelStride, u.toByte())
                vb.put(y * vp.rowStride + x * vp.pixelStride, v.toByte())
            }
        }
    }

    /** Renders the scene frame by frame, encodes H.264 + AAC and muxes into an MP4 file. */
    fun export(p: RenderParams, out: File, onProgress: (Int) -> Unit) {
        val aac = encodeAudio(p.pcm, p.durationMs)
        val w = p.width
        val h = p.height
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, p.videoBitrate)
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, p.fps)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        val venc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        venc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        venc.start()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var vTrack = -1
        var aTrack = -1
        var started = false
        var ai = 0
        val info = MediaCodec.BufferInfo()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val renderer = SceneRenderer(w, h, p.scene, p.beats)
        val pixels = IntArray(w * h)
        val row = ByteArray(w)
        val totalFrames = ceil(p.durationMs * p.fps / 1000.0).toInt().coerceAtLeast(1)

        fun writeAudioUpTo(limitUs: Long) {
            while (ai < aac.samples.size && aac.samples[ai].ptsUs <= limitUs) {
                val s = aac.samples[ai++]
                val bi = MediaCodec.BufferInfo()
                bi.set(0, s.data.size, s.ptsUs, 0)
                muxer.writeSampleData(aTrack, ByteBuffer.wrap(s.data), bi)
            }
        }

        fun drain(eos: Boolean) {
            var spins = 0
            while (true) {
                val o = venc.dequeueOutputBuffer(info, if (eos) 10_000L else 0L)
                if (o == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!eos) return
                    if (++spins > 600) return
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    vTrack = muxer.addTrack(venc.outputFormat)
                    aTrack = muxer.addTrack(aac.format)
                    muxer.start()
                    started = true
                } else if (o >= 0) {
                    val ob = venc.getOutputBuffer(o)!!
                    if (info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && started) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        writeAudioUpTo(info.presentationTimeUs)
                        muxer.writeSampleData(vTrack, ob, info)
                    }
                    venc.releaseOutputBuffer(o, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }

        fun nextInput(): Int {
            var idx = venc.dequeueInputBuffer(10_000)
            while (idx < 0) {
                drain(false)
                idx = venc.dequeueInputBuffer(10_000)
            }
            return idx
        }

        try {
            for (f in 0 until totalFrames) {
                renderer.draw(canvas, f / p.fps.toFloat())
                bmp.getPixels(pixels, 0, w, 0, 0, w, h)
                val idx = nextInput()
                val img = venc.getInputImage(idx) ?: error("This phone's encoder can't take YUV frames")
                fillImage(img, pixels, w, h, row)
                venc.queueInputBuffer(idx, 0, w * h * 3 / 2, f * 1_000_000L / p.fps, 0)
                drain(false)
                onProgress(((f + 1) * 100L / totalFrames).toInt())
            }
            val last = nextInput()
            venc.queueInputBuffer(last, 0, 0, totalFrames * 1_000_000L / p.fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(true)
            if (started) writeAudioUpTo(Long.MAX_VALUE)
        } finally {
            try { venc.stop() } catch (e: Exception) { }
            venc.release()
            try { if (started) muxer.stop() } catch (e: Exception) { }
            muxer.release()
            bmp.recycle()
        }
    }
}
