package com.example.beatclipai

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * The app is offline. The ONLY code that opens a network connection is KidPacks,
 * and it refuses to run unless a monthly import window is open.
 */
object NetworkGate {
    private const val PREFS = "beatclip_net"
    private const val MONTH_MS = 30L * 24 * 60 * 60 * 1000
    private const val WINDOW_MS = 30L * 60 * 1000

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun normalise(ctx: Context) {
        val p = prefs(ctx)
        val s = p.getLong("sessionStart", 0L)
        // A window that timed out without finishing (app killed, no Wi-Fi) is closed WITHOUT using up the month.
        if (s > 0L && System.currentTimeMillis() - s >= WINDOW_MS) {
            p.edit().putLong("sessionStart", 0L).apply()
        }
    }

    fun sessionOpen(ctx: Context): Boolean {
        normalise(ctx)
        return prefs(ctx).getLong("sessionStart", 0L) > 0L
    }

    fun canStart(ctx: Context): Boolean {
        normalise(ctx)
        val last = prefs(ctx).getLong("lastEnd", 0L)
        return last == 0L || System.currentTimeMillis() - last >= MONTH_MS
    }

    fun start(ctx: Context): Boolean {
        if (!canStart(ctx)) return false
        prefs(ctx).edit().putLong("sessionStart", System.currentTimeMillis()).apply()
        return true
    }

    /** Import worked: close the window and lock the network for a month. */
    fun finish(ctx: Context) {
        prefs(ctx).edit().putLong("lastEnd", System.currentTimeMillis()).putLong("sessionStart", 0L).apply()
    }

    /** Import got nothing (e.g. no Wi-Fi): close the window without using up the month. */
    fun cancel(ctx: Context) {
        prefs(ctx).edit().putLong("sessionStart", 0L).apply()
    }

    fun requireOpen(ctx: Context) {
        check(sessionOpen(ctx)) { "Offline mode: the network is only used during the monthly import." }
    }

    fun nextText(ctx: Context): String {
        normalise(ctx)
        val last = prefs(ctx).getLong("lastEnd", 0L)
        if (last == 0L) return "Ready for the first import!"
        val next = last + MONTH_MS
        if (System.currentTimeMillis() >= next) return "Ready for this month's import!"
        return "Next import opens on " + SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(next))
    }
}

object KidPacks {
    private const val UA = "BeatClipKids/1.0 (Android; monthly picture import)"
    private const val PER_TOPIC = 3

    private val blocked = listOf(
        "nude", "naked", "nudity", "erotic", "sex", "sexual", "porn", "gore", "blood", "bloody", "corpse",
        "dead", "death", "war", "weapon", "gun", "rifle", "bomb", "skull", "drug", "alcohol", "beer", "wine",
        "cigarette", "tobacco", "violence", "murder", "kill", "nazi", "swastika", "bikini", "lingerie",
        "underwear", "topless", "fetish", "hunting", "slaughter", "autopsy", "surgery", "wound"
    )
    private val blockedRe = Regex("\\b(" + blocked.joinToString("|") + ")\\b", RegexOption.IGNORE_CASE)
    private val tagStrip = Regex("<[^>]*>")

    private fun open(ctx: Context, url: String, readMs: Int): HttpURLConnection {
        NetworkGate.requireOpen(ctx)
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = readMs
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        return c
    }

    private fun getText(ctx: Context, url: String): String {
        val c = open(ctx, url, 30000)
        try {
            if (c.responseCode !in 200..299) error("server said ${c.responseCode}")
            return c.inputStream.bufferedReader().readText()
        } finally { c.disconnect() }
    }

    private class Candidate(val title: String, val url: String, val credit: String)

    private fun search(ctx: Context, topic: ImportTopic): List<Candidate> {
        val exclude = listOf("nude", "naked", "nudity", "erotic", "sex", "gore", "blood", "war", "weapon").joinToString(" ") { "-$it" }
        val q = "${topic.query} filetype:bitmap incategory:\"Featured pictures on Wikimedia Commons\" $exclude"
        val url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search" +
            "&gsrnamespace=6&gsrlimit=20&gsrsearch=" + URLEncoder.encode(q, "UTF-8") +
            "&prop=imageinfo&iiprop=url%7Cextmetadata&iiurlwidth=1280"
        val pages = JSONObject(getText(ctx, url)).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val out = ArrayList<Candidate>()
        val keys = pages.keys()
        while (keys.hasNext()) {
            val page = pages.getJSONObject(keys.next())
            val info = page.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
            val thumb = info.optString("thumburl", info.optString("url"))
            val ext = thumb.substringAfterLast('.').lowercase()
            if (ext != "jpg" && ext != "jpeg" && ext != "png" && ext != "webp") continue
            val meta = info.optJSONObject("extmetadata")
            val title = page.optString("title").removePrefix("File:").substringBeforeLast('.')
            val cats = meta?.optJSONObject("Categories")?.optString("value") ?: ""
            val desc = meta?.optJSONObject("ImageDescription")?.optString("value") ?: ""
            if (blockedRe.containsMatchIn("$title $cats ${desc.replace(tagStrip, " ")}")) continue
            val artist = (meta?.optJSONObject("Artist")?.optString("value") ?: "").replace(tagStrip, "").trim()
            val lic = meta?.optJSONObject("LicenseShortName")?.optString("value") ?: ""
            out.add(Candidate(title.take(60), thumb, listOf(artist.take(40), lic).filter { it.isNotBlank() }.joinToString(" • ")))
        }
        return out
    }

    /** Downloads a few kid-safe pictures per chosen topic. Only call from inside an open import window. */
    fun importTopics(ctx: Context, topics: List<ImportTopic>, dir: File, onStatus: (String) -> Unit): List<OfflineAsset> {
        val result = ArrayList<OfflineAsset>()
        for (topic in topics) {
            onStatus("Getting ${topic.label} pictures… 📥")
            val found = search(ctx, topic).take(PER_TOPIC)
            for (cnd in found) {
                val ext = cnd.url.substringAfterLast('.').lowercase().let { if (it == "jpeg") "jpg" else it }
                val id = UUID.randomUUID().toString()
                val f = File(dir, "$id.$ext")
                val c = open(ctx, cnd.url, 60000)
                try {
                    if (c.responseCode !in 200..299) continue
                    c.inputStream.use { ins -> f.outputStream().use { ins.copyTo(it) } }
                } finally { c.disconnect() }
                result.add(OfflineAsset(id, cnd.title, f.path, false, cnd.credit))
                onStatus("Saved ${result.size} pictures so far… ✨")
            }
        }
        return result
    }
}
