package com.example.beatclipai

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Raw 16-bit little-endian interleaved PCM stored on disk. */
class PcmAudio(val file: File, val sampleRate: Int, val channels: Int, val frames: Long) {
    val durationMs: Long get() = frames * 1000L / sampleRate
}

/** Loudness envelopes plus a drift-corrected list of beat times (seconds). */
class BeatMap(
    val hopSec: Float,
    val level: FloatArray,
    val bass: FloatArray,
    val beats: FloatArray,
    val period: Float
) {
    val bpm: Float get() = 60f / period

    /** Continuous beat position: integer part = beat number, fraction = progress to next beat. */
    fun beatPos(t: Float): Float {
        if (beats.isEmpty()) return t / period
        if (t < beats[0]) return (t - beats[0]) / period
        var hi = beats.size - 1
        if (t >= beats[hi]) return hi + (t - beats[hi]) / period
        var lo = 0
        while (hi - lo > 1) {
            val mid = (lo + hi) / 2
            if (beats[mid] <= t) lo = mid else hi = mid
        }
        return lo + (t - beats[lo]) / max(1e-3f, beats[hi] - beats[lo])
    }

    fun levelAt(t: Float): Float =
        if (level.isEmpty()) 0f else level[(t / hopSec).toInt().coerceIn(0, level.size - 1)]

    fun bassAt(t: Float): Float =
        if (bass.isEmpty()) 0f else bass[(t / hopSec).toInt().coerceIn(0, bass.size - 1)]
}

object AudioTools {

    /** Decodes any audio file the phone can play (MP3, M4A, WAV, OGG...) to PCM on disk. */
    fun decode(context: Context, uri: Uri, out: File, maxMs: Long): PcmAudio {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(context, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)
                if (mime != null && mime.startsWith("audio/")) { track = i; break }
            }
            require(track >= 0) { "no audio track found" }
            ex.selectTrack(track)
            val fmt = ex.getTrackFormat(track)
            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = dec
            dec.configure(fmt, null, null, 0)
            dec.start()
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var frames = 0L
            BufferedOutputStream(FileOutputStream(out), 1 shl 16).use { os ->
                while (!outDone) {
                    if (!inDone) {
                        val i = dec.dequeueInputBuffer(10_000)
                        if (i >= 0) {
                            val buf = dec.getInputBuffer(i)!!
                            val n = ex.readSampleData(buf, 0)
                            if (n < 0) {
                                dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inDone = true
                            } else {
                                dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                                ex.advance()
                            }
                        }
                    }
                    val o = dec.dequeueOutputBuffer(info, 10_000)
                    if (o >= 0) {
                        val ob = dec.getOutputBuffer(o)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val outCh = min(ch, 2)
                        val nFrames = sb.remaining() / ch
                        val bytes = ByteArray(nFrames * outCh * 2)
                        var k = 0
                        for (f in 0 until nFrames) {
                            for (cc in 0 until outCh) {
                                val sv = sb.get(f * ch + cc).toInt()
                                bytes[k++] = sv.toByte()
                                bytes[k++] = (sv shr 8).toByte()
                            }
                        }
                        os.write(bytes)
                        frames += nFrames
                        dec.releaseOutputBuffer(o, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 ||
                            frames * 1000L >= maxMs * sr
                        ) outDone = true
                    } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val nf = dec.outputFormat
                        sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            }
            return PcmAudio(out, sr, min(ch, 2), min(frames, maxMs * sr / 1000))
        } finally {
            try { codec?.stop() } catch (e: Exception) { }
            codec?.release()
            ex.release()
        }
    }

    private fun normalise(a: List<Float>): FloatArray {
        val arr = a.toFloatArray()
        if (arr.isEmpty()) return arr
        val sorted = arr.sortedArray()
        val ref = max(1e-6f, sorted[(sorted.size * 0.98).toInt().coerceAtMost(sorted.size - 1)])
        return FloatArray(arr.size) { (arr[it] / ref).coerceIn(0f, 1f) }
    }

    /** Finds tempo and beat positions automatically from the audio. */
    fun analyze(pcm: PcmAudio): BeatMap {
        val hop = max(1, pcm.sampleRate / 50)
        val hopSec = hop / pcm.sampleRate.toFloat()
        val lv = ArrayList<Float>()
        val bs = ArrayList<Float>()
        val alpha = (2.0 * PI * 150.0 / pcm.sampleRate).toFloat().coerceIn(0.001f, 0.5f)
        var lp = 0f
        var accL = 0.0
        var accB = 0.0
        var n = 0
        var idx = 0
        var sum = 0f
        var left = pcm.frames * pcm.channels
        FileInputStream(pcm.file).channel.use { chn ->
            val bb = ByteBuffer.allocate(1 shl 16).order(ByteOrder.LITTLE_ENDIAN)
            while (left > 0 && chn.read(bb) > 0) {
                bb.flip()
                while (bb.remaining() >= 2 && left > 0) {
                    sum += bb.getShort().toFloat() / 32768f
                    left--
                    idx++
                    if (idx == pcm.channels) {
                        val m = sum / pcm.channels
                        lp += alpha * (m - lp)
                        accL += (m * m).toDouble()
                        accB += (lp * lp).toDouble()
                        n++
                        if (n == hop) {
                            lv.add(sqrt(accL / n).toFloat())
                            bs.add(sqrt(accB / n).toFloat())
                            accL = 0.0; accB = 0.0; n = 0
                        }
                        idx = 0
                        sum = 0f
                    }
                }
                bb.compact()
            }
        }
        val level = normalise(lv)
        val bass = normalise(bs)
        val cnt = level.size

        // Onset strength: how fast the (mostly bass) energy rises.
        val on = FloatArray(cnt)
        for (i in 1 until cnt) {
            on[i] = max(0f, 0.7f * (bass[i] - bass[i - 1]) + 0.3f * (level[i] - level[i - 1]))
        }

        // Best phase for one beat period (in hops): returns (score, phase).
        fun comb(per: Float): Pair<Float, Int> {
            var best = -1f
            var bestPh = 0
            for (ph in 0 until ceil(per).toInt()) {
                var s = 0f
                var c = 0
                var x = ph.toFloat()
                while (x < cnt - 2) {
                    val j = x.roundToInt().coerceIn(1, cnt - 2)
                    s += max(on[j], max(on[j - 1], on[j + 1]))
                    c++
                    x += per
                }
                if (c > 0 && s / c > best) { best = s / c; bestPh = ph }
            }
            return best to bestPh
        }

        // Search tempo 70-170 BPM for the grid that lines up best with the onsets.
        var bestScore = -1f
        var bestPer = 0.5f / hopSec
        var bestPhase = 0
        var bpmC = 70f
        while (bpmC <= 170f) {
            val per = 60f / bpmC / hopSec
            val (sc, ph) = comb(per)
            if (sc > bestScore) { bestScore = sc; bestPer = per; bestPhase = ph }
            bpmC += 0.25f
        }
        if (bestScore < 1e-4f) {
            bestPer = 0.5f / hopSec
            bestPhase = 0
        } else if (60f / (bestPer * hopSec) < 100f) {
            // Slow reading? If double speed fits almost as well, the song is really twice as fast.
            val (s2, p2) = comb(bestPer / 2f)
            if (s2 >= 0.92f * bestScore) { bestPer /= 2f; bestPhase = p2 }
        }

        // Track beats through the song. Nudge phase AND tempo toward local onset peaks,
        // so slow drift and tempo changes are followed instead of building up.
        val beats = ArrayList<Float>()
        var tk = bestPhase.toFloat()
        var per = bestPer
        val per0 = bestPer
        val win = max(1, (bestPer * 0.25f).toInt())
        while (tk < cnt) {
            val c = tk.roundToInt().coerceIn(0, max(0, cnt - 1))
            var bj = c
            var bv = -1f
            for (j in max(0, c - win)..min(cnt - 1, c + win)) {
                if (on[j] > bv) { bv = on[j]; bj = j }
            }
            if (bv > 0.05f) {
                val e = bj - tk
                tk += 0.5f * e
                per = (per + 0.2f * e).coerceIn(per0 * 0.75f, per0 * 1.3f)
            }
            beats.add(tk * hopSec)
            tk += per
        }
        val period = if (beats.size > 1) (beats.last() - beats.first()) / (beats.size - 1) else bestPer * hopSec
        return BeatMap(hopSec, level, bass, beats.toFloatArray(), period)
    }

    /** Offline beat generator: kick, off-beat hats and a simple bassline, 60 seconds, mono. */
    fun synth(out: File): PcmAudio {
        val sr = 44100
        val bpm = (100..128).random()
        val beatSamples = (sr * 60.0 / bpm).toInt()
        val total = sr * 60
        val notes = doubleArrayOf(55.0, 55.0, 65.41, 49.0)
        val rnd = java.util.Random(5)
        var kickPhase = 0.0
        BufferedOutputStream(FileOutputStream(out), 1 shl 16).use { os ->
            val chunk = ByteArray(sr * 2)
            for (sec in 0 until 60) {
                for (j in 0 until sr) {
                    val i = sec * sr + j
                    val inBeat = i % beatSamples
                    val beatNo = i / beatSamples
                    if (inBeat == 0) kickPhase = 0.0
                    val t = inBeat / sr.toDouble()
                    val kf = 45.0 + 110.0 * exp(-t * 28.0)
                    kickPhase += 2.0 * PI * kf / sr
                    val kick = sin(kickPhase) * exp(-t * 9.0) * 0.9
                    val off = ((i + beatSamples / 2) % beatSamples) / sr.toDouble()
                    val hat = (rnd.nextDouble() * 2.0 - 1.0) * exp(-off * 70.0) * 0.22
                    val note = notes[(beatNo / 2) % 4]
                    val bass = sin(2.0 * PI * note * i / sr) * exp(-off * 6.0) * 0.35
                    val v = ((kick + hat + bass) * 0.8).coerceIn(-1.0, 1.0)
                    val s = (v * 32767).toInt()
                    chunk[j * 2] = s.toByte()
                    chunk[j * 2 + 1] = (s shr 8).toByte()
                }
                os.write(chunk)
            }
        }
        return PcmAudio(out, sr, 1, total.toLong())
    }
}
