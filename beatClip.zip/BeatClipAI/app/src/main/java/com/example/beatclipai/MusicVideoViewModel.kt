package com.example.beatclipai

import android.app.Application
import android.content.ContentValues
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.min
import kotlin.math.roundToInt

class MusicVideoViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application get() = getApplication()
    private val _ui = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _ui.asStateFlow()
    private fun upd(f: (StudioUiState) -> StudioUiState) { _ui.update(f) }

    private var pcm: PcmAudio? = null
    /** Finger strokes recorded during preview; the export replays them so everyone points in the video too. */
    val touches = CopyOnWriteArrayList<TouchStroke>()
    private var beatMap: BeatMap? = null
    private val packsDir: File = File(app.filesDir, "packs").apply { mkdirs() }
    private val pickedDir: File = File(app.filesDir, "picked").apply { mkdirs() }
    private val maxAudioMs = 15L * 60 * 1000

    init {
        upd {
            it.copy(
                savedOfflineAssets = loadIndex(),
                canStartImport = NetworkGate.canStart(app),
                nextImportText = NetworkGate.nextText(app)
            )
        }
    }

    // ---------- simple setters ----------
    fun setTab(i: Int) = upd { it.copy(activeTab = i) }
    fun updateSongTitle(s: String) = upd { it.copy(songTitle = s.take(60)) }
    fun updateArtistName(s: String) = upd { it.copy(artistName = s.take(60)) }
    fun updateLyrics(s: String) = upd { it.copy(lyricsText = s.take(20000)) }
    fun setDanceStyle(d: DanceStyle) = upd { it.copy(danceStyle = d) }
    fun setRecordTouches(b: Boolean) = upd { it.copy(recordTouches = b) }
    fun addTouchStroke(st: TouchStroke) { touches.add(st); upd { it.copy(touchCount = touches.size) } }
    fun clearTouches() { touches.clear(); upd { it.copy(touchCount = 0) } }
    fun setEnvironment(e: BackgroundEnvironment) = upd { it.copy(environment = e) }
    fun toggleSubject(s: AnimatedSubject) = upd {
        it.copy(selectedSubjects = if (s in it.selectedSubjects) it.selectedSubjects - s else it.selectedSubjects + s)
    }
    fun setPortrait(p: Boolean) = upd { it.copy(isPortrait = p) }
    fun setFullSongMode() = upd { it.copy(useFullAudioDuration = true) }
    fun setPreviewSeconds(sec: Int) = upd { it.copy(useFullAudioDuration = false, previewSeconds = sec) }
    fun setQuality(q: VideoQuality) = upd { it.copy(selectedQuality = q) }
    fun closeDownloadPopup() = upd { it.copy(showDownloadDialog = false) }
    fun toggleImportTopic(t: ImportTopic) = upd {
        it.copy(selectedImportTopics = if (t in it.selectedImportTopics) it.selectedImportTopics - t else it.selectedImportTopics + t)
    }

    fun selectColorPreset(p: ColorPalettePreset) = upd { it.copy(colorScheme = ColorScheme.of(p)) }
    fun updateColors(primaryHue: Float? = null, secondaryHue: Float? = null, accentHue: Float? = null, vibrancy: Float? = null) =
        upd {
            val c = it.colorScheme
            it.copy(
                colorScheme = ColorScheme(
                    ColorPalettePreset.CUSTOM,
                    primaryHue ?: c.primaryHue, secondaryHue ?: c.secondaryHue,
                    accentHue ?: c.accentHue, vibrancy ?: c.vibrancy
                )
            )
        }

    fun toggleOfflineAsset(id: String) = upd {
        it.copy(selectedOfflineAssetIds = if (id in it.selectedOfflineAssetIds) it.selectedOfflineAssetIds - id else it.selectedOfflineAssetIds + id)
    }

    fun deleteOfflineAsset(id: String) {
        val a = _ui.value.savedOfflineAssets.firstOrNull { it.id == id } ?: return
        File(a.filePath).delete()
        val rest = _ui.value.savedOfflineAssets.filter { it.id != id }
        saveIndex(rest)
        upd { it.copy(savedOfflineAssets = rest, selectedOfflineAssetIds = it.selectedOfflineAssetIds - id) }
    }

    // ---------- song ----------
    private fun displayName(uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "Song"
            }
        } catch (e: Exception) { }
        return uri.lastPathSegment ?: "Song"
    }

    private fun fmt(ms: Long): String = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

    fun onAudioPicked(uri: Uri) {
        upd { it.copy(isWorking = true, progressPercent = 0, statusText = "Listening to your song… 👂") }
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val name = displayName(uri)
                val decoded = AudioTools.decode(ctx, uri, File(ctx.cacheDir, "song.pcm"), maxAudioMs)
                val map = AudioTools.analyze(decoded)
                pcm = decoded; beatMap = map; touches.clear()
                upd {
                    it.copy(
                        isWorking = false,
                        audioLabel = "$name • ${fmt(decoded.durationMs)} • ${map.bpm.roundToInt()} beats/min",
                        songTitle = if (it.songTitle.isBlank()) name.substringBeforeLast('.').take(60) else it.songTitle,
                        statusText = "Song ready! The dancers found the beat 🥁"
                    )
                }
            } catch (e: Exception) {
                upd { it.copy(isWorking = false, statusText = "Oops, couldn't read that song: ${e.message}") }
            }
        }
    }

    fun generateSynthBeat() {
        upd { it.copy(isWorking = true, progressPercent = 0, statusText = "Making a beat… 🥁") }
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val a = AudioTools.synth(File(ctx.cacheDir, "song.pcm"))
                val map = AudioTools.analyze(a)
                pcm = a; beatMap = map; touches.clear()
                upd {
                    it.copy(
                        isWorking = false,
                        audioLabel = "Made-up beat • ${fmt(a.durationMs)} • ${map.bpm.roundToInt()} beats/min",
                        songTitle = if (it.songTitle.isBlank()) "My Beat" else it.songTitle,
                        statusText = "Beat ready! 🎶"
                    )
                }
            } catch (e: Exception) {
                upd { it.copy(isWorking = false, statusText = "Oops, couldn't make a beat: ${e.message}") }
            }
        }
    }

    fun onLyricsFilePicked(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().take(100_000).toByteArray().toString(Charsets.UTF_8) } ?: ""
                upd { it.copy(lyricsText = text.take(20000), statusText = "Song words loaded! 📝") }
            } catch (e: Exception) {
                upd { it.copy(statusText = "Couldn't read that words file.") }
            }
        }
    }

    // ---------- backgrounds ----------
    fun onCustomBackgroundsPicked(uris: List<Uri>) {
        upd { it.copy(statusText = "Getting your pictures… 🖼️") }
        viewModelScope.launch(Dispatchers.IO) {
            pickedDir.listFiles()?.forEach { it.delete() }
            val out = uris.mapIndexedNotNull { i, u ->
                try {
                    val mime = ctx.contentResolver.getType(u) ?: ""
                    val f = File(pickedDir, "bg$i." + if (mime.startsWith("video")) "mp4" else "jpg")
                    ctx.contentResolver.openInputStream(u)?.use { ins -> f.outputStream().use { ins.copyTo(it) } }
                    Uri.fromFile(f)
                } catch (e: Exception) { null }
            }
            upd { it.copy(customBackgroundUris = out, statusText = "${out.size} picture(s) ready! 🎉") }
        }
    }

    fun clearCustomBackgrounds() {
        upd { it.copy(customBackgroundUris = emptyList()) }
        viewModelScope.launch(Dispatchers.IO) { pickedDir.listFiles()?.forEach { it.delete() } }
    }

    // ---------- live preview ----------
    fun previewPcm(): PcmAudio? = pcm
    fun previewBeats(): BeatMap? = beatMap

    /** Builds the scene from the current choices. The caller must call BackdropLoader.release on its backdrops. */
    fun buildScene(w: Int, h: Int, snapshot: Boolean = false): Scene {
        val st = _ui.value
        val files = st.customBackgroundUris.mapNotNull { u -> u.path?.let { File(it) } } +
            st.savedOfflineAssets.filter { it.id in st.selectedOfflineAssetIds }.map { File(it.filePath) }
        val backdrops = BackdropLoader.load(files, w, h)
        val lyrics = LyricsParser.parse(st.lyricsText, effectiveDurationMs() / 1000f, beatMap)
        val pointing: List<TouchStroke> = if (snapshot) touches.toList() else touches
        return Scene(st.environment, st.selectedSubjects.toList(), st.colorScheme, backdrops, st.songTitle, st.artistName, lyrics, st.danceStyle, pointing)
    }

    // ---------- export ----------
    fun effectiveDurationMs(): Long {
        val st = _ui.value
        val full = pcm?.durationMs ?: (st.previewSeconds * 1000L)
        return if (st.useFullAudioDuration) full else min(full, st.previewSeconds * 1000L)
    }

    fun openDownloadPopup() {
        if (pcm == null) {
            upd { it.copy(statusText = "Pick a song or make a beat first! 🎵") }
            return
        }
        upd { it.copy(showDownloadDialog = true) }
    }

    private fun dims(shortSide: Int, portrait: Boolean): Pair<Int, Int> {
        var long = (shortSide * 16 / 9f).roundToInt()
        if (long % 2 != 0) long++
        return if (portrait) shortSide to long else long to shortSide
    }

    fun exportVideo(saveToDownloadsFolder: Boolean) {
        val st = _ui.value
        val audio = pcm ?: return
        val map = beatMap ?: return
        val dur = effectiveDurationMs()
        upd { it.copy(showDownloadDialog = false, isWorking = true, progressPercent = 0, exportedVideoUri = null, statusText = "Making your music video… 🎬 (keep the app open)") }
        viewModelScope.launch(Dispatchers.Default) {
            val tmp = File(ctx.cacheDir, "render.mp4")
            try {
                val q = st.selectedQuality
                val first = dims(q.shortSide, st.isPortrait)
                val second = ((first.first + 15) / 16 * 16) to ((first.second + 15) / 16 * 16)
                val attempts = if (second == first) listOf(first) else listOf(first, second)
                var done = false
                var lastErr: Throwable? = null
                for ((w, h) in attempts) {
                    var backdrops: List<BgItem> = emptyList()
                    try {
                        val scene = buildScene(w, h, snapshot = true)
                        backdrops = scene.backdrops
                        var last = -1
                        VideoExporter.export(RenderParams(audio, map, dur, w, h, 30, q.bitrate, scene), tmp) { pct ->
                            if (pct != last) { last = pct; upd { it.copy(progressPercent = pct) } }
                        }
                        done = true
                    } catch (e: Throwable) {
                        lastErr = e
                    } finally {
                        BackdropLoader.release(backdrops)
                    }
                    if (done) break
                }
                if (!done) throw (lastErr ?: IllegalStateException("render failed"))
                val uri = saveToMediaStore(tmp, saveToDownloadsFolder)
                upd {
                    it.copy(
                        isWorking = false, exportedVideoUri = uri, progressPercent = 100,
                        statusText = if (saveToDownloadsFolder) "Saved in Downloads/BeatClipAI 🎉" else "Saved in Movies/BeatClipAI 🎉"
                    )
                }
            } catch (e: Throwable) {
                upd { it.copy(isWorking = false, statusText = "Oops, the video didn't finish: ${e.message}") }
            } finally {
                tmp.delete()
            }
        }
    }

    private fun saveToMediaStore(src: File, downloads: Boolean): Uri {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "BeatClip_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, if (downloads) "Download/BeatClipAI" else "Movies/BeatClipAI")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = if (downloads) MediaStore.Downloads.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = resolver.insert(collection, values) ?: error("could not create the video file")
        resolver.openOutputStream(uri)!!.use { out -> src.inputStream().use { it.copyTo(out) } }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri
    }

    // ---------- monthly import (the only time the network is used) ----------
    fun importNow() {
        val st = _ui.value
        if (st.isImporting || st.selectedImportTopics.isEmpty()) return
        if (!NetworkGate.start(ctx)) {
            upd { it.copy(importStatus = it.nextImportText, canStartImport = false) }
            return
        }
        upd { it.copy(isImporting = true, importStatus = "Connecting… 🌐") }
        viewModelScope.launch(Dispatchers.IO) {
            var got = 0
            var failure: String? = null
            try {
                val assets = KidPacks.importTopics(ctx, st.selectedImportTopics.toList(), packsDir) { msg ->
                    upd { it.copy(importStatus = msg) }
                }
                got = assets.size
                if (got > 0) {
                    val all = assets + _ui.value.savedOfflineAssets
                    saveIndex(all)
                    upd { it.copy(savedOfflineAssets = all) }
                }
            } catch (e: Exception) {
                failure = e.message
            } finally {
                if (got > 0) NetworkGate.finish(ctx) else NetworkGate.cancel(ctx)
                upd {
                    it.copy(
                        isImporting = false,
                        canStartImport = NetworkGate.canStart(ctx),
                        nextImportText = NetworkGate.nextText(ctx),
                        importStatus = when {
                            got > 0 -> "Done! $got new pictures saved. Back to offline mode ✈️"
                            failure != null -> "Couldn't import ($failure). Try again later - this didn't use up your month."
                            else -> "No pictures found. This didn't use up your month."
                        }
                    )
                }
            }
        }
    }

    // ---------- saved pictures index ----------
    private fun saveIndex(list: List<OfflineAsset>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("path", it.filePath).put("video", it.isVideo).put("credit", it.credit))
        }
        File(packsDir, "index.json").writeText(arr.toString())
    }

    private fun loadIndex(): List<OfflineAsset> {
        val f = File(packsDir, "index.json")
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).mapNotNull {
                val o = arr.getJSONObject(it)
                val fp = o.getString("path")
                if (File(fp).exists()) OfflineAsset(o.getString("id"), o.getString("title"), fp, o.optBoolean("video"), o.optString("credit")) else null
            }
        } catch (e: Exception) { emptyList() }
    }
}
