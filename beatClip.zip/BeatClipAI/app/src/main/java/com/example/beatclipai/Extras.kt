package com.example.beatclipai

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private val SKINS2 = intArrayOf(0xFFFFDBB4.toInt(), 0xFFF1C27D.toInt(), 0xFFC68642.toInt(), 0xFF8D5524.toInt(), 0xFFFFE0C2.toInt())
private val HAIRS2 = intArrayOf(0xFF3B2314.toInt(), 0xFF1C1C1C.toInt(), 0xFFB5651D.toInt(), 0xFFE8B84A.toInt(), 0xFFD2503C.toInt())

private fun SceneRenderer.pick(i: Int): Int = when (i % 3) { 0 -> prim; 1 -> sec; else -> acc }

// ---------------- turtle ----------------
internal fun SceneRenderer.turtle(c: Canvas, cx: Float, gy: Float, sz: Float, m: Mo, idx: Int, tgt: FloatArray?) {
    val green = 0xFF6BCB77.toInt()
    val shell = mix(pick(idx), 0xFF2E7D32.toInt(), .4f)
    val ol = sz * 0.014f
    val jump = m.air * 0.05f * sz
    val sq = 1f - 0.07f * m.kick
    val mid = gy - sz * 0.10f
    shadow(c, cx, gy, sz * 0.36f, m.air)
    c.save(); c.rotate(m.sway * 4f, cx, gy); c.translate(0f, -jump)
    for (k in 0..1) {
        val off = if (k == 0) -0.22f else 0.20f
        val lx = cx + off * sz + (if (k == 0) m.sway else -m.sway) * sz * 0.02f
        blob(c, RectF(lx - sz * 0.075f, gy - sz * 0.16f, lx + sz * 0.075f, gy + sz * 0.005f), green, ol)
    }
    path.reset(); path.moveTo(cx - sz * 0.34f, mid - sz * 0.03f); path.lineTo(cx - sz * 0.48f + m.sway2 * sz * 0.04f, mid + sz * 0.01f); path.lineTo(cx - sz * 0.34f, mid + sz * 0.04f); path.close()
    c.drawPath(path, fillP(green)); c.drawPath(path, strokeP(OUT, ol))
    val reach = if (tgt != null) ((tgt[0] - cx) / (W * 0.5f)).coerceIn(-1f, 1f) else 0f
    val hx = cx + sz * 0.43f + m.kick * sz * 0.03f + (if (tgt != null) abs(reach) * sz * 0.05f else 0f)
    val hy = mid - sz * 0.10f - m.air * sz * 0.02f - (if (tgt != null) max(0f, (gy - tgt[1]) / H) * sz * 0.1f else 0f)
    limb(c, cx + sz * 0.28f, mid - sz * 0.02f, hx, hy + sz * 0.02f, sz * 0.10f, green, ol)
    val hr = sz * 0.12f
    blob(c, RectF(hx - hr, hy - hr, hx + hr, hy + hr), green, ol)
    face(c, hx + hr * 0.12f, hy, hr, m.blink, 1f, if (tgt != null) 0.8f else m.kick * 0.7f)
    val belly = RectF(cx - sz * 0.37f, mid - sz * 0.03f, cx + sz * 0.37f, mid + sz * 0.06f)
    c.drawRoundRect(belly, sz * 0.045f, sz * 0.045f, fillP(mix(green, Color.WHITE, .4f)))
    c.drawRoundRect(belly, sz * 0.045f, sz * 0.045f, strokeP(OUT, ol))
    val sh = RectF(cx - sz * 0.36f, mid - sz * 0.30f * sq, cx + sz * 0.36f, mid + sz * 0.30f * sq)
    c.drawArc(sh, 180f, 180f, true, fillP(shell)); c.drawArc(sh, 180f, 180f, true, strokeP(OUT, ol))
    val hxs = floatArrayOf(0f, -0.2f, 0.2f)
    val hys = floatArrayOf(0.17f, 0.08f, 0.08f)
    val hrs = floatArrayOf(0.085f, 0.07f, 0.07f)
    for (j in 0..2) {
        path.reset()
        for (i in 0 until 6) {
            val a = PI.toFloat() / 3f * i + PI.toFloat() / 6f
            val x = cx + hxs[j] * sz + cos(a) * hrs[j] * sz
            val y = mid - hys[j] * sz * sq + sin(a) * hrs[j] * sz * 0.85f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, fillP(mix(shell, Color.WHITE, .35f), .9f)); c.drawPath(path, strokeP(mix(shell, OUT, .4f), ol * 0.7f))
    }
    c.restore()
}

// ---------------- mermaid ----------------
internal fun SceneRenderer.mermaid(c: Canvas, cx: Float, gy: Float, sz: Float, m: Mo, idx: Int, tgt: FloatArray?) {
    val skin = SKINS2[(idx + 1) % 5]
    val tail = pick(idx)
    val hair = HAIRS2[(idx * 2 + 3) % 5]
    val ol = sz * 0.014f
    shadow(c, cx, gy, sz * 0.2f, m.air)
    val jump = m.air * 0.04f * sz
    val hipy = gy - sz * 0.42f - jump
    val n = 18
    val px = FloatArray(n)
    val py = FloatArray(n)
    for (k in 0 until n) {
        val f = k / (n - 1f)
        px[k] = cx + sin(f * 3.2f - m.pos * PIF) * sz * 0.05f * f + m.sway2 * sz * 0.12f * f * f
        py[k] = hipy + f * sz * 0.40f
    }
    for (k in 0 until n) c.drawCircle(px[k], py[k], sz * 0.085f * (1f - 0.65f * k / (n - 1f)) + ol, fillP(OUT))
    for (k in 0 until n) c.drawCircle(px[k], py[k], sz * 0.085f * (1f - 0.65f * k / (n - 1f)), fillP(mix(tail, Color.WHITE, if ((k / 2) % 2 == 0) 0f else .18f)))
    val ex = px[n - 1]
    val ey = py[n - 1]
    val sw = m.sway2
    for (side in intArrayOf(-1, 1)) {
        path.reset(); path.moveTo(ex, ey)
        path.quadTo(ex + side * sz * 0.2f + sw * sz * 0.05f, ey - sz * 0.06f, ex + side * sz * 0.17f + sw * sz * 0.08f, ey - sz * 0.15f)
        path.quadTo(ex + side * sz * 0.04f, ey - sz * 0.07f, ex, ey); path.close()
        c.drawPath(path, fillP(mix(tail, acc, .4f))); c.drawPath(path, strokeP(OUT, ol))
    }
    val shy = hipy - sz * 0.25f
    val ptSide = if (tgt == null) 0 else if (tgt[0] < cx) -1 else 1
    for (side in intArrayOf(-1, 1)) {
        var hx2 = cx + side * sz * (0.17f + 0.05f * max(0f, side * m.sway))
        var hy2 = shy - sz * (0.04f + 0.1f * (0.5f + 0.5f * side * m.sway))
        if (tgt != null && side == ptSide) {
            val ang = atan2(tgt[0] - (cx + side * sz * 0.07f), tgt[1] - (shy + sz * 0.03f))
            hx2 = cx + side * sz * 0.07f + sin(ang) * sz * 0.22f
            hy2 = shy + sz * 0.03f + cos(ang) * sz * 0.22f
        }
        limb(c, cx + side * sz * 0.07f, shy + sz * 0.03f, hx2, hy2, sz * 0.045f, skin, ol)
    }
    val r = sz * 0.1f
    val hcx = cx
    val hcy = shy - r * 1.05f
    for (pass in 0..1) {
        for (k in -1..1) {
            path.reset(); path.moveTo(hcx + k * r * 0.7f, hcy)
            path.quadTo(hcx + k * r * 1.5f + m.sway2 * sz * 0.07f, hcy + sz * 0.15f, hcx + k * r * 1.2f + m.sway2 * sz * 0.12f, hcy + sz * 0.32f)
            if (pass == 0) c.drawPath(path, strokeP(OUT, sz * 0.055f + ol * 2f)) else c.drawPath(path, strokeP(hair, sz * 0.055f))
        }
    }
    blob(c, RectF(cx - sz * 0.08f, shy, cx + sz * 0.08f, hipy + sz * 0.05f), skin, ol)
    for (side in intArrayOf(-1, 1)) blob(c, RectF(cx + side * sz * 0.04f - sz * 0.04f, shy + sz * 0.07f, cx + side * sz * 0.04f + sz * 0.04f, shy + sz * 0.14f), acc, ol * .7f)
    blob(c, RectF(hcx - r, hcy - r, hcx + r, hcy + r), skin, ol)
    c.drawArc(RectF(hcx - r * 1.04f, hcy - r * 1.04f, hcx + r * 1.04f, hcy + r * 1.04f), 195f, 150f, true, fillP(hair))
    val look = if (tgt != null) ((tgt[0] - hcx) / (sz * 0.9f)).coerceIn(-1f, 1f) else m.sway
    face(c, hcx, hcy + r * 0.05f, r, m.blink, look, if (tgt != null) 0.7f else m.kick * 0.6f)
}

// ---------------- flower ----------------
internal fun SceneRenderer.flower(c: Canvas, cx: Float, gy: Float, sz: Float, m: Mo, idx: Int, tgt: FloatArray?) {
    val green = 0xFF3FA34D.toInt()
    val ol = sz * 0.014f
    shadow(c, cx, gy, sz * 0.12f, m.air)
    val lean = if (tgt != null) ((tgt[0] - cx) / (W * 0.4f)).coerceIn(-1f, 1f) else m.sway
    val tx = cx + lean * sz * 0.16f
    val ty = gy - sz * 0.62f - m.air * sz * 0.04f
    path.reset(); path.moveTo(cx, gy); path.quadTo(cx - lean * sz * 0.03f, gy - sz * 0.35f, tx, ty)
    c.drawPath(path, strokeP(OUT, sz * 0.045f + ol * 2f)); c.drawPath(path, strokeP(green, sz * 0.045f))
    for (side in intArrayOf(-1, 1)) {
        c.save(); c.translate(cx + m.sway * sz * 0.04f, gy - sz * 0.25f); c.rotate(side * (30f + m.sway2 * 14f))
        blob(c, RectF(min(0f, side * sz * 0.2f), -sz * 0.045f, max(0f, side * sz * 0.2f), sz * 0.045f), green, ol); c.restore()
    }
    val r = sz * (0.115f + 0.015f * m.kick)
    val petal = pick(idx)
    for (k in 0 until 10) {
        c.save(); c.translate(tx, ty); c.rotate(k * 36f + m.pos * 18f)
        blob(c, RectF(-r * 0.36f, -r * 1.75f, r * 0.36f, -r * 0.55f), if (k % 2 == 0) petal else mix(petal, Color.WHITE, .35f), ol * .8f); c.restore()
    }
    blob(c, RectF(tx - r * 0.95f, ty - r * 0.95f, tx + r * 0.95f, ty + r * 0.95f), 0xFFFFE066.toInt(), ol)
    face(c, tx, ty, r * 0.95f, m.blink, lean, if (tgt != null) 0.9f else m.kick)
}

// ---------------- floaters ----------------
internal fun SceneRenderer.stars(c: Canvas, m: Mo) {
    for (i in 0 until 12) {
        val x = W * (0.08f + 0.84f * hash(i * 3 + 1))
        val y = H * (0.05f + 0.5f * hash(i * 5 + 2))
        val r = u * (0.025f + 0.03f * hash(i * 7 + 3)) * (1f + 0.6f * m.kick * (if (i % 2 == 0) 1f else .5f))
        val col = when (i % 3) { 0 -> acc; 1 -> Color.WHITE; else -> sec }
        glow(c, x, y, r * 2.2f, col, .35f)
        star4(c, x, y, r * 1.5f, col, .95f)
    }
}

private fun SceneRenderer.fishOne(c: Canvas, cx: Float, cy: Float, fs: Float, col: Int, m: Mo, t: Float, k: Int) {
    val ol = fs * 0.04f
    c.save(); c.rotate(sin(t * 6f + k) * 6f, cx, cy)
    val fin = mix(col, Color.WHITE, .3f)
    path.reset(); path.moveTo(cx - fs * 0.8f, cy)
    path.quadTo(cx - fs * 1.2f, cy - fs * 0.15f + m.sway * fs * 0.1f, cx - fs * 1.5f, cy - fs * 0.5f + m.sway * fs * 0.15f)
    path.quadTo(cx - fs * 1.25f, cy, cx - fs * 1.5f, cy + fs * 0.5f + m.sway * fs * 0.15f)
    path.quadTo(cx - fs * 1.2f, cy + fs * 0.15f + m.sway * fs * 0.1f, cx - fs * 0.8f, cy); path.close()
    c.drawPath(path, fillP(fin)); c.drawPath(path, strokeP(OUT, ol))
    path.reset(); path.moveTo(cx - fs * 0.3f, cy - fs * 0.42f); path.quadTo(cx, cy - fs * 0.85f, cx + fs * 0.35f, cy - fs * 0.42f); path.close()
    c.drawPath(path, fillP(fin)); c.drawPath(path, strokeP(OUT, ol))
    val body = RectF(cx - fs, cy - fs * 0.55f, cx + fs, cy + fs * 0.55f)
    c.drawOval(body, fillP(col))
    c.drawOval(RectF(cx - fs * 0.8f, cy + fs * 0.05f, cx + fs * 0.7f, cy + fs * 0.5f), fillP(mix(col, Color.WHITE, .5f), .6f))
    for (sx in floatArrayOf(-0.35f, 0f)) c.drawLine(cx + sx * fs, cy - fs * 0.45f, cx + sx * fs - fs * 0.05f, cy + fs * 0.45f, strokeP(mix(col, OUT, .35f), fs * 0.09f, .5f))
    c.drawOval(body, strokeP(OUT, ol))
    c.drawCircle(cx + fs * 0.55f, cy - fs * 0.1f, fs * 0.17f, fillP(Color.WHITE))
    c.drawCircle(cx + fs * 0.6f, cy - fs * 0.1f, fs * 0.09f, fillP(OUT))
    c.drawCircle(cx + fs * 0.63f, cy - fs * 0.14f, fs * 0.03f, fillP(Color.WHITE))
    c.drawArc(RectF(cx + fs * 0.72f, cy + fs * 0.05f, cx + fs * 0.95f, cy + fs * 0.22f), 20f, 140f, false, strokeP(OUT, fs * 0.04f))
    c.restore()
    for (j in 0..2) {
        c.drawCircle(cx + fs * (1.1f + j * 0.25f), cy - fs * (0.2f + j * 0.28f) + sin(t * 4f + j) * fs * 0.05f, fs * (0.06f + j * 0.02f), strokeP(Color.WHITE, fs * 0.025f, .6f))
    }
}

internal fun SceneRenderer.fish(c: Canvas, t: Float, m: Mo, tgt: FloatArray?) {
    for (i in 0 until 5) {
        val fs = u * (0.07f + 0.02f * hash(i + 4)) * 1.2f
        val span = W + 4f * fs
        var x = (t * u * (0.09f + 0.03f * i) + i * W * 0.37f) % span - 2f * fs
        var y = H * (0.22f + 0.1f * i) + sin(t * 2f + i) * u * 0.02f - m.kick * u * 0.01f
        if (tgt != null) {                      // swim over to the finger
            x += (tgt[0] - x) * 0.6f + cos(t * 2f + i * 2f) * u * 0.08f
            y += (tgt[1] - y) * 0.6f + sin(t * 2.3f + i) * u * 0.05f
        }
        val col = when (i % 3) { 0 -> prim; 1 -> sec; else -> acc }
        fishOne(c, x, y, fs, col, m, t, i)
    }
}

internal fun SceneRenderer.butterflies(c: Canvas, t: Float, m: Mo, tgt: FloatArray?) {
    for (i in 0 until 5) {
        var cx0 = W * (0.15f + 0.7f * hash(i * 3 + 9)) + sin(t * 0.8f + i * 2f) * u * 0.12f
        var cy0 = H * (0.25f + 0.3f * hash(i * 5 + 4)) + cos(t * 0.6f + i) * u * 0.06f - m.kick * u * 0.01f
        if (tgt != null) {                      // flutter around the finger
            cx0 = tgt[0] + cos(t * 2f + i * 1.3f) * u * 0.1f
            cy0 = tgt[1] + sin(t * 2.4f + i * 1.3f) * u * 0.07f
        }
        val sz = u * (0.05f + 0.02f * hash(i + 20)) * 1.2f
        val flap = 0.25f + 0.75f * abs(cos(2f * PIF * m.pos + i))
        val col = if (i % 2 == 0) prim else sec
        val col2 = mix(col, Color.WHITE, .45f)
        val ol = sz * 0.05f
        for (side in intArrayOf(-1, 1)) {
            c.save(); c.translate(cx0, cy0); c.scale(side * flap, 1f)
            val up = RectF(0f, -sz * 1.05f, sz * 1.35f, sz * 0.2f)
            val lo = RectF(0f, -sz * 0.1f, sz * 0.95f, sz * 0.95f)
            c.drawOval(lo, fillP(col2)); c.drawOval(lo, strokeP(OUT, ol))
            c.drawOval(up, fillP(col)); c.drawOval(up, strokeP(OUT, ol))
            c.drawCircle(sz * 0.7f, -sz * 0.45f, sz * 0.2f, fillP(Color.WHITE, .85f))
            c.drawCircle(sz * 0.45f, sz * 0.4f, sz * 0.12f, fillP(0xFFFFE066.toInt()))
            c.restore()
        }
        c.drawLine(cx0, cy0 - sz * 0.5f, cx0, cy0 + sz * 0.6f, strokeP(OUT, sz * 0.15f))
        for (side in intArrayOf(-1, 1)) c.drawLine(cx0, cy0 - sz * 0.5f, cx0 + side * sz * 0.25f, cy0 - sz * 0.85f, strokeP(OUT, sz * 0.05f))
        c.drawCircle(cx0, cy0 - sz * 0.5f, sz * 0.12f, fillP(OUT))
    }
}
