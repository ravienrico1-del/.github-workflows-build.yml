package com.example.beatclipai

/** One finger-down-to-finger-up gesture, with times in song seconds and positions as 0..1 of the screen. */
class TouchStroke(val t: FloatArray, val x: FloatArray, val y: FloatArray)

object Touches {
    /** Where was the finger at song time [time]? null if nobody was touching. */
    fun pointAt(list: List<TouchStroke>, time: Float): FloatArray? {
        var found: FloatArray? = null
        var foundStart = -1f
        for (st in list) {
            if (st.t.isEmpty()) continue
            if (time >= st.t[0] && time <= st.t[st.t.size - 1] + 0.25f && st.t[0] >= foundStart) {
                var lo = 0
                var hi = st.t.size - 1
                while (lo < hi) {
                    val mid = (lo + hi + 1) / 2
                    if (st.t[mid] <= time) lo = mid else hi = mid - 1
                }
                found = floatArrayOf(st.x[lo], st.y[lo])
                foundStart = st.t[0]
            }
        }
        return found
    }
}
