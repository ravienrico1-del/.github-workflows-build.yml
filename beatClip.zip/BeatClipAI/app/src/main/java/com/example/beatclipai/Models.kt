package com.example.beatclipai

import android.graphics.Color as AColor
import android.net.Uri

enum class BackgroundEnvironment(val label: String) {
    BEACH("🏖️ Beach"), FOREST("🌲 Forest"), SPACE("🚀 Space"), CITY("🌃 City Night"), SUNSET("🌅 Sunset"),
    UNDERWATER("🌊 Underwater"), NEON_GRID("🪩 Disco Grid"), FLOWER_FIELD("🌼 Flower Field"),
    AURORA("🌌 Aurora"), BOKEH("✨ Glow Bokeh"), ABSTRACT("🎨 Colour Blobs")
}

enum class AnimatedSubject(val label: String) {
    KIDS("💃 Kids"), BUNNIES("🐰 Bunnies"), PUPPIES("🐶 Puppies"), BEARS("🐻 Bears"), PANDAS("🐼 Pandas"),
    PENGUINS("🐧 Penguins"), FROGS("🐸 Frogs"), FOXES("🦊 Foxes"), CATS("🐱 Cats"),
    TURTLES("🐢 Turtles"), MERMAIDS("🧜 Mermaids"), FLOWERS("🌸 Flowers"),
    FISH("🐠 Fish"), BUTTERFLIES("🦋 Butterflies"), STARS("⭐ Stars")
}

enum class DanceStyle(val label: String) {
    MIX("🎲 Mix it up"), DISCO("🕺 Disco"), CHACHA("💃 Cha-cha"), BALLROOM("🎩 Ballroom"), LINE("🤠 Line dance"),
    STEPPING("👣 Stepping"), RAVE("🪩 Rave"), ROBOT("🤖 Pop & lock"), FLOSS("🌀 Floss")
}

enum class ColorPalettePreset(val label: String, val p: Float, val s: Float, val a: Float, val vib: Float) {
    NEON("Neon", 300f, 190f, 60f, 1f),
    SUNSET_P("Sunset", 15f, 330f, 45f, 0.9f),
    OCEAN("Ocean", 200f, 170f, 280f, 0.85f),
    FOREST_P("Forest", 125f, 85f, 50f, 0.7f),
    CANDY("Candy", 330f, 190f, 50f, 0.8f),
    MONO("Soft", 220f, 220f, 220f, 0.25f),
    CUSTOM("Custom", 0f, 0f, 0f, 1f)
}

private fun hsv(h: Float, s: Float, v: Float): Int {
    var hh = h % 360f
    if (hh < 0f) hh += 360f
    return AColor.HSVToColor(floatArrayOf(hh, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))
}

data class ColorScheme(
    val preset: ColorPalettePreset = ColorPalettePreset.NEON,
    val primaryHue: Float = 300f,
    val secondaryHue: Float = 190f,
    val accentHue: Float = 60f,
    val vibrancy: Float = 1f
) {
    fun primaryColor(): Int = hsv(primaryHue, 0.30f + 0.70f * vibrancy, 0.55f + 0.45f * vibrancy)
    fun secondaryColor(): Int = hsv(secondaryHue, 0.30f + 0.70f * vibrancy, 0.45f + 0.45f * vibrancy)
    fun accentColor(): Int = hsv(accentHue, 0.20f + 0.80f * vibrancy, 1f)

    companion object {
        fun of(p: ColorPalettePreset) = ColorScheme(p, p.p, p.s, p.a, p.vib)
    }
}

enum class VideoQuality(val label: String, val desc: String, val shortSide: Int, val bitrate: Int) {
    SD("Standard 480p", "Small file, fastest", 480, 2_500_000),
    HD("HD 720p", "Great for sharing", 720, 6_000_000),
    FHD("Full HD 1080p", "Best quality, slower", 1080, 12_000_000);

    fun estimateSizeMb(durationMs: Long): Double =
        (bitrate + 128_000) / 8.0 * (durationMs / 1000.0) / 1_000_000.0
}

/** Fixed, kid-safe picture topics for the monthly import. There is no free-text search. */
enum class ImportTopic(val label: String, val query: String) {
    OCEAN("🌊 Ocean", "ocean waves"),
    FLOWERS("🌸 Flowers", "flowers"),
    RAINBOW("🌈 Rainbow", "rainbow"),
    ANIMALS("🐱 Cute Animals", "kitten"),
    SPACE("🌌 Space", "galaxy"),
    FOREST("🌲 Forest", "forest"),
    BEACH("🏖️ Beach", "tropical beach"),
    BUTTERFLIES("🦋 Butterflies", "butterfly"),
    GARDEN("🌻 Garden", "garden"),
    CLOUDS("☁️ Sky", "clouds sky")
}

data class OfflineAsset(
    val id: String,
    val title: String,
    val filePath: String,
    val isVideo: Boolean,
    val credit: String
)

data class StudioUiState(
    val activeTab: Int = 0,
    val audioLabel: String = "No song yet",
    val songTitle: String = "",
    val artistName: String = "",
    val lyricsText: String = "",
    val isWorking: Boolean = false,
    val progressPercent: Int = 0,
    val statusText: String = "Pick a song or make a beat to start! 🎵",
    val environment: BackgroundEnvironment = BackgroundEnvironment.BEACH,
    val customBackgroundUris: List<Uri> = emptyList(),
    val savedOfflineAssets: List<OfflineAsset> = emptyList(),
    val selectedOfflineAssetIds: Set<String> = emptySet(),
    val selectedSubjects: Set<AnimatedSubject> = setOf(AnimatedSubject.BUNNIES, AnimatedSubject.KIDS),
    val danceStyle: DanceStyle = DanceStyle.MIX,
    val recordTouches: Boolean = true,
    val touchCount: Int = 0,
    val colorScheme: ColorScheme = ColorScheme.of(ColorPalettePreset.NEON),
    val isPortrait: Boolean = true,
    val useFullAudioDuration: Boolean = true,
    val previewSeconds: Int = 30,
    val exportedVideoUri: Uri? = null,
    val showDownloadDialog: Boolean = false,
    val selectedQuality: VideoQuality = VideoQuality.HD,
    val selectedImportTopics: Set<ImportTopic> = setOf(ImportTopic.OCEAN, ImportTopic.FLOWERS, ImportTopic.RAINBOW),
    val isImporting: Boolean = false,
    val importStatus: String = "",
    val canStartImport: Boolean = true,
    val nextImportText: String = ""
)
