package com.example.beatclipai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import androidx.core.graphics.ColorUtils
import java.io.File
import kotlin.math.PI
import kotlin.math.sqrt
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

sealed class BgItem {
    class Img(val bmp: Bitmap) : BgItem()
    class Vid(val mmr: MediaMetadataRetriever, val durUs: Long) : BgItem() {
        var bucket = -1L
        var frame: Bitmap? = null
    }
}

class Scene(
    val environment: BackgroundEnvironment,
    val subjects: List<AnimatedSubject>,
    val colors: ColorScheme,
    val backdrops: List<BgItem>,
    val title: String,
    val artist: String,
    val lyrics: List<LyricLine>,
    val style: DanceStyle,
    val touches: List<TouchStroke>
)

object BackdropLoader {
    private val videoExt = setOf("mp4", "webm", "mkv", "mov", "3gp", "ogv", "m4v")

    fun load(files: List<File>, w: Int, h: Int): List<BgItem> = files.mapNotNull { f ->
        try {
            if (f.extension.lowercase() in videoExt) loadVideo(f) else loadImage(f, w, h)
        } catch (e: Throwable) { null }
    }

    private fun loadImage(f: File, w: Int, h: Int): BgItem? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= w && o.outHeight / (sample * 2) >= h) sample *= 2
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        return BgItem.Img(bmp)
    }

    private fun loadVideo(f: File): BgItem? {
        val m = MediaMetadataRetriever()
        m.setDataSource(f.path)
        val d = (m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
        if (d <= 0L) { m.release(); return null }
        return BgItem.Vid(m, d)
    }

    fun release(items: List<BgItem>) {
        for (i in items) {
            try {
                when (i) {
                    is BgItem.Img -> i.bmp.recycle()
                    is BgItem.Vid -> { i.frame?.recycle(); i.mmr.release() }
                }
            } catch (e: Throwable) { }
        }
    }
}


/** Movement signals for one frame, all derived from the beat position. */
internal class Mo(val pos: Float, val t: Float) {
    private val fl = floor(pos)
    val beat = fl.toInt()
    val ph = pos - fl
    val kick = exp(-ph * 7f)                                   // 1 on the beat, quick decay
    val air = sin(PI.toFloat() * ph)                           // 0 on the beat, 1 mid-beat (jump arc)
    val sway = cos(PI.toFloat() * pos)                         // smooth left-right
    val sway2 = cos(PI.toFloat() * pos - 0.9f)                 // lagging copy for hair, ears, tails
    val blink = (t % 3.3f) < 0.12f
}

class SceneRenderer(internal val w: Int, internal val h: Int, internal val s: Scene, internal val bm: BeatMap) {
    internal val PIF = PI.toFloat()
    internal val W = w.toFloat()
    internal val H = h.toFloat()
    internal val u = min(W, H)
    internal val p = Paint(Paint.ANTI_ALIAS_FLAG)
    internal val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; strokeJoin = Paint.Join.ROUND }
    internal val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    internal val path = Path()
    internal val prim = s.colors.primaryColor()
    internal val sec = s.colors.secondaryColor()
    internal val acc = s.colors.accentColor()
    internal val OUT = 0xFF2B2140.toInt()
    internal val WHITE = Color.WHITE
    private var lyricIdx = 0

    /** Set by the live preview while a finger is down: x, y as 0..1 of the screen. */
    @Volatile var livePointer: FloatArray? = null

    private val mixOrder = arrayOf(
        DanceStyle.DISCO, DanceStyle.CHACHA, DanceStyle.LINE, DanceStyle.STEPPING,
        DanceStyle.BALLROOM, DanceStyle.RAVE, DanceStyle.ROBOT, DanceStyle.FLOSS
    )
    private val grounded = setOf(
        AnimatedSubject.KIDS, AnimatedSubject.BUNNIES, AnimatedSubject.PUPPIES, AnimatedSubject.BEARS,
        AnimatedSubject.PANDAS, AnimatedSubject.PENGUINS, AnimatedSubject.FROGS, AnimatedSubject.FOXES,
        AnimatedSubject.CATS, AnimatedSubject.TURTLES, AnimatedSubject.MERMAIDS, AnimatedSubject.FLOWERS
    )

    // ---------- small drawing helpers ----------
    internal fun mix(a: Int, b: Int, f: Float) = ColorUtils.blendARGB(a, b, f)

    internal fun hash(i: Int): Float {
        val v = sin(i * 12.9898f) * 43758.5453f
        return v - floor(v)
    }

    internal fun fillP(color: Int, a: Float = 1f): Paint {
        p.reset(); p.isAntiAlias = true
        p.color = color; p.alpha = (255 * a).toInt().coerceIn(0, 255)
        return p
    }

    internal fun strokeP(color: Int, width: Float, a: Float = 1f): Paint {
        p.reset(); p.isAntiAlias = true
        p.style = Paint.Style.STROKE; p.strokeWidth = width
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        p.color = color; p.alpha = (255 * a).toInt().coerceIn(0, 255)
        return p
    }

    internal fun vgrad(c: Canvas, y0: Float, y1: Float, top: Int, bot: Int) {
        p.reset()
        p.shader = LinearGradient(0f, y0, 0f, y1, top, bot, Shader.TileMode.CLAMP)
        c.drawRect(0f, y0, W, y1, p)
    }

    /** Soft round light: colour at the centre fading to nothing at radius r. */
    internal fun glow(c: Canvas, x: Float, y: Float, r: Float, color: Int, a: Float) {
        p.reset()
        p.shader = RadialGradient(
            x, y, r, ColorUtils.setAlphaComponent(color, (255 * a).toInt().coerceIn(0, 255)),
            ColorUtils.setAlphaComponent(color, 0), Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, p)
    }

    internal fun limb(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, wd: Float, col: Int, ol: Float) {
        c.drawLine(x1, y1, x2, y2, strokeP(OUT, wd + ol * 2f))
        c.drawLine(x1, y1, x2, y2, strokeP(col, wd))
    }

    internal fun blob(c: Canvas, rc: RectF, col: Int, ol: Float) {
        c.drawOval(rc, fillP(col))
        c.drawOval(rc, strokeP(OUT, ol))
    }

    internal fun shadow(c: Canvas, cx: Float, gy: Float, w2: Float, air: Float) {
        val k = 1f - 0.3f * air
        c.drawOval(RectF(cx - w2 * k, gy - w2 * 0.12f, cx + w2 * k, gy + w2 * 0.12f), fillP(Color.BLACK, .22f))
    }

    internal fun face(c: Canvas, x: Float, y: Float, r: Float, blink: Boolean, look: Float, open: Float, cheeks: Boolean = true) {
        val ex = r * 0.38f
        val ey = y - r * 0.05f
        val er = r * 0.21f
        for (side in intArrayOf(-1, 1)) {
            val cx = x + side * ex
            if (blink) {
                c.drawLine(cx - er, ey, cx + er, ey, strokeP(OUT, r * 0.07f))
            } else {
                val rc = RectF(cx - er * 0.9f, ey - er, cx + er * 0.9f, ey + er)
                c.drawOval(rc, fillP(WHITE))
                c.drawOval(rc, strokeP(OUT, r * 0.03f))
                val px = cx + look * er * 0.3f
                c.drawCircle(px, ey + er * 0.1f, er * 0.62f, fillP(OUT))
                c.drawCircle(px + er * 0.22f, ey - er * 0.25f, er * 0.22f, fillP(WHITE))
            }
        }
        if (cheeks) {
            for (side in intArrayOf(-1, 1)) c.drawCircle(x + side * r * 0.64f, y + r * 0.3f, r * 0.17f, fillP(0xFFFF8FA3.toInt(), .55f))
        }
        val my = y + r * 0.42f
        if (open > 0.15f) {
            val oh = r * (0.06f + 0.24f * open)
            c.drawOval(RectF(x - r * 0.2f, my - r * 0.06f, x + r * 0.2f, my + oh), fillP(0xFF8B1E3F.toInt()))
            c.drawOval(RectF(x - r * 0.11f, my + oh - r * 0.1f, x + r * 0.11f, my + oh), fillP(0xFFFF8FA3.toInt()))
        } else {
            c.drawArc(RectF(x - r * 0.22f, my - r * 0.2f, x + r * 0.22f, my + r * 0.1f), 15f, 150f, false, strokeP(OUT, r * 0.07f))
        }
    }

    internal fun star4(c: Canvas, x: Float, y: Float, r: Float, col: Int, a: Float) {
        path.reset()
        for (k in 0 until 8) {
            val rad = if (k % 2 == 0) r else r * 0.28f
            val ang = k * PIF / 4f - PIF / 2f
            if (k == 0) path.moveTo(x + cos(ang) * rad, y + sin(ang) * rad) else path.lineTo(x + cos(ang) * rad, y + sin(ang) * rad)
        }
        path.close()
        c.drawPath(path, fillP(col, a))
    }

    internal fun cloud(c: Canvas, x: Float, y: Float, sz: Float, a: Float) {
        val dxs = floatArrayOf(0f, 0.9f, -0.9f, 0.35f, -0.35f)
        val dys = floatArrayOf(0f, 0.15f, 0.2f, -0.35f, -0.2f)
        val rs = floatArrayOf(1.0f, 0.8f, 0.75f, 0.8f, 0.7f)
        for (i in 0 until 5) c.drawCircle(x + dxs[i] * sz, y + dys[i] * sz, rs[i] * sz * 0.6f, fillP(WHITE, a))
        c.drawOval(RectF(x - sz * 1.5f, y + sz * 0.1f, x + sz * 1.5f, y + sz * 0.62f), fillP(WHITE, a))
    }

    internal fun hills(c: Canvas, base: Float, amp: Float, wl: Float, ph: Float, col: Int, scroll: Float) {
        path.reset(); path.moveTo(0f, H)
        var x = 0f
        while (x <= W + 16f) {
            path.lineTo(x, base + sin((x + scroll) / wl * 2f * PIF + ph) * amp + sin((x + scroll) / wl * 5f * PIF + ph * 2f) * amp * 0.3f)
            x += 16f
        }
        path.lineTo(W, H); path.close()
        c.drawPath(path, fillP(col))
    }

    internal fun wave(c: Canvas, y: Float, amp: Float, wl: Float, ph: Float, col: Int, a: Float, sw: Float) {
        path.reset(); path.moveTo(0f, y)
        var x = 0f
        while (x <= W + 12f) { path.lineTo(x, y + sin(x / wl * 2f * PIF + ph) * amp); x += 12f }
        c.drawPath(path, strokeP(col, sw, a))
    }

    private fun flare(c: Canvas, sx: Float, sy: Float) {
        for (k in 1..4) {
            val x = sx + (W / 2f - sx) * k * 0.4f
            val y = sy + (H / 2f - sy) * k * 0.4f
            val r = u * 0.025f * k
            val col = when (k % 4) { 0 -> prim; 1 -> WHITE; 2 -> sec; else -> acc }
            c.drawCircle(x, y, r, fillP(col, 0.10f))
            c.drawCircle(x, y, r, strokeP(WHITE, u * 0.004f, 0.12f))
        }
    }

    private fun vignette(c: Canvas) {
        p.reset()
        p.shader = RadialGradient(
            W / 2f, H / 2f, sqrt(W * W + H * H) / 2f,
            intArrayOf(0x00000000, 0x00000000, 0x59000000), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, W, H, p)
    }

    private fun sparkles(c: Canvas, m: Mo, gy: Float) {
        for (k in 0 until 14) {
            val sd = m.beat * 13 + k
            val x = W * hash(sd * 3 + 1)
            val y = gy - m.ph * H * (0.18f + 0.3f * hash(sd * 5 + 2))
            val r = u * (0.008f + 0.014f * hash(sd + 9)) * (1f - m.ph * 0.6f)
            val col = when (k % 4) { 0 -> acc; 1 -> WHITE; 2 -> prim; else -> sec }
            star4(c, x, y, r * 1.6f, col, 0.85f * (1f - m.ph))
        }
    }

    /** Glowing rings where a finger is touching, so you can see it is being noticed. */
    private fun touchRipple(c: Canvas, tgt: FloatArray, t: Float) {
        glow(c, tgt[0], tgt[1], u * 0.12f, acc, 0.55f)
        for (k in 0 until 3) {
            val f = (t * 1.6f + k / 3f) % 1f
            c.drawCircle(tgt[0], tgt[1], u * (0.025f + 0.09f * f), strokeP(WHITE, u * 0.006f, 0.8f * (1f - f)))
        }
        star4(c, tgt[0], tgt[1], u * 0.03f, WHITE, 0.95f)
    }

    private fun styleAt(m: Mo): DanceStyle =
        if (s.style == DanceStyle.MIX) mixOrder[max(0, m.beat / 4) % mixOrder.size] else s.style

    private fun speciesOf(a: AnimatedSubject): Species? = when (a) {
        AnimatedSubject.KIDS -> Species.KID
        AnimatedSubject.BUNNIES -> Species.BUNNY
        AnimatedSubject.PUPPIES -> Species.PUPPY
        AnimatedSubject.BEARS -> Species.BEAR
        AnimatedSubject.PANDAS -> Species.PANDA
        AnimatedSubject.PENGUINS -> Species.PENGUIN
        AnimatedSubject.FROGS -> Species.FROG
        AnimatedSubject.FOXES -> Species.FOX
        AnimatedSubject.CATS -> Species.CAT
        else -> null
    }

    // ---------- main entry ----------
    fun draw(c: Canvas, t: Float) {
        val m = Mo(bm.beatPos(t), t)
        val bass = bm.bassAt(t)
        val ptr = livePointer ?: Touches.pointAt(s.touches, t)
        val tgt: FloatArray? = if (ptr != null) floatArrayOf(ptr[0] * W, ptr[1] * H) else null

        // slow cinematic camera drift on the scenery
        c.save()
        val z = 1.05f + 0.015f * sin(t * 0.25f)
        c.scale(z, z, W / 2f, H / 2f)
        c.translate(sin(t * 0.17f) * u * 0.015f, cos(t * 0.13f) * u * 0.01f)
        background(c, t, m, bass)
        c.restore()

        if (AnimatedSubject.STARS in s.subjects) stars(c, m)
        if (AnimatedSubject.FISH in s.subjects) fish(c, t, m, tgt)
        if (AnimatedSubject.BUTTERFLIES in s.subjects) butterflies(c, t, m, tgt)

        val g = s.subjects.filter { it in grounded }
        if (g.isNotEmpty()) {
            val frontN = if (w < h) 3 else 4
            val szF = min(u * 0.62f, W / frontN * 1.7f)
            val style = styleAt(m)
            for (row in 0..1) {
                val n = if (row == 0) frontN - 1 else frontN
                val sz = if (row == 0) szF * 0.78f else szF
                val gy = if (row == 0) H * 0.855f else H * 0.90f
                for (i in 0 until n) {
                    val cx = if (row == 0) W * (i + 1f) / frontN else W * (i + 0.5f) / frontN
                    val slot = (if (row == 0) 0 else frontN - 1) + i
                    val sub = g[slot % g.size]
                    val sp = speciesOf(sub)
                    if (sp != null) {
                        drawRig(c, sp, cx, gy, sz, m, poseFor(style, m, i % 2 == 1), slot, tgt)
                    } else when (sub) {
                        AnimatedSubject.TURTLES -> turtle(c, cx, gy, sz * 0.8f, m, slot, tgt)
                        AnimatedSubject.MERMAIDS -> mermaid(c, cx, gy, sz, m, slot, tgt)
                        else -> flower(c, cx, gy, sz * 0.9f, m, slot, tgt)
                    }
                }
            }
        }

        sparkles(c, m, H * 0.9f)
        if (tgt != null) touchRipple(c, tgt, t)
        vignette(c)
        val flash = 0.10f * m.kick * (0.4f + 0.6f * bass)
        if (flash > 0.01f) c.drawRect(0f, 0f, W, H, fillP(acc, flash))
        titleText(c)
        lyrics(c, t, m.kick)
    }

    // ---------- scenery ----------
    private fun frameOf(item: BgItem.Vid, t: Float): Bitmap? {
        val tUs = (t * 1_000_000f).toLong() % max(1L, item.durUs)
        val bucket = tUs / 125_000L
        if (bucket != item.bucket) {
            item.bucket = bucket
            val nf = try { item.mmr.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST) } catch (e: Exception) { null }
            if (nf != null) {
                val old = item.frame
                item.frame = nf
                old?.recycle()
            }
        }
        return item.frame
    }

    private fun drawCover(c: Canvas, bmp: Bitmap, zoom: Float) {
        val sc = max(W / bmp.width, H / bmp.height) * zoom
        val dw = bmp.width * sc
        val dh = bmp.height * sc
        c.drawBitmap(bmp, null, RectF((W - dw) / 2f, (H - dh) / 2f, (W + dw) / 2f, (H + dh) / 2f), bmpPaint)
    }

    private fun background(c: Canvas, t: Float, m: Mo, bass: Float) {
        if (s.backdrops.isNotEmpty()) {
            val item = s.backdrops[max(0, m.beat / 8) % s.backdrops.size]
            val bmp = when (item) {
                is BgItem.Img -> item.bmp
                is BgItem.Vid -> frameOf(item, t)
            }
            if (bmp != null) drawCover(c, bmp, 1f + 0.03f * m.kick + 0.02f * bass) else c.drawColor(Color.BLACK)
            c.drawRect(0f, 0f, W, H, fillP(prim, 0.14f))
            return
        }
        drawEnvironment(c, s.environment, t, m, bass)
        if (s.environment == BackgroundEnvironment.FLOWER_FIELD) flare(c, W * 0.2f, H * 0.12f)
        if (s.environment == BackgroundEnvironment.BEACH) flare(c, W * 0.75f, H * 0.2f)
    }

    // ---------- text ----------
    private fun fit(text: String, maxChars: Int) = if (text.length > maxChars) text.take(maxChars - 1) + "…" else text

    private fun titleText(c: Canvas) {
        if (s.title.isBlank() && s.artist.isBlank()) return
        tp.textAlign = Paint.Align.CENTER
        var y = H * 0.06f
        if (s.title.isNotBlank()) {
            tp.textSize = u * 0.05f
            outlined(c, fit(s.title, 30), W / 2f, y, tp.textSize)
            y += u * 0.06f
        }
        if (s.artist.isNotBlank()) {
            tp.textSize = u * 0.035f
            outlined(c, fit(s.artist, 36), W / 2f, y, tp.textSize)
        }
    }

    private fun outlined(c: Canvas, text: String, x: Float, y: Float, size: Float) {
        tp.style = Paint.Style.STROKE; tp.strokeWidth = size * 0.16f; tp.color = Color.BLACK
        c.drawText(text, x, y, tp)
        tp.style = Paint.Style.FILL; tp.color = Color.WHITE
        c.drawText(text, x, y, tp)
    }

    private fun wrap(text: String, size: Float, maxW: Float): List<String> {
        tp.textSize = size
        val rows = ArrayList<String>()
        var cur = ""
        for (word in text.split(" ").filter { it.isNotEmpty() }) {
            val trial = if (cur.isEmpty()) word else "$cur $word"
            if (tp.measureText(trial) <= maxW || cur.isEmpty()) cur = trial else { rows.add(cur); cur = word }
        }
        if (cur.isNotEmpty()) rows.add(cur)
        return rows.take(3)
    }

    /** Karaoke-style words: the current line fills with colour as the song moves through it. */
    private fun lyrics(c: Canvas, t: Float, kick: Float) {
        val ls = s.lyrics
        if (ls.isEmpty()) return
        while (lyricIdx + 1 < ls.size && t >= ls[lyricIdx + 1].start) lyricIdx++
        while (lyricIdx > 0 && t < ls[lyricIdx].start) lyricIdx--
        val cur = ls[lyricIdx]
        if (t < cur.start || t > cur.end + 0.5f) return
        val prog = ((t - cur.start) / max(0.1f, cur.end - cur.start)).coerceIn(0f, 1f)
        val size = u * 0.062f * (1f + 0.04f * kick)
        tp.textAlign = Paint.Align.LEFT
        val rows = wrap(cur.text, size, W * 0.88f)
        if (rows.isEmpty()) return
        tp.textSize = size
        val lh = size * 1.25f
        val top = H * 0.15f
        val maxRow = rows.maxOf { tp.measureText(it) }
        c.drawRoundRect(
            RectF(W / 2f - maxRow / 2f - size * 0.6f, top - size * 0.2f, W / 2f + maxRow / 2f + size * 0.6f, top + lh * rows.size + size * 0.25f),
            size * 0.5f, size * 0.5f, fillP(Color.BLACK, .45f)
        )
        val total = max(1, rows.sumOf { it.length })
        var before = 0
        for ((r, row) in rows.withIndex()) {
            tp.textSize = size
            val rw = tp.measureText(row)
            val x = W / 2f - rw / 2f
            val y = top + lh * (r + 1)
            outlined(c, row, x, y, size)
            val fr = ((prog * total - before) / max(1, row.length)).coerceIn(0f, 1f)
            if (fr > 0f) {
                c.save(); c.clipRect(x, y - size * 1.2f, x + rw * fr, y + size * 0.4f)
                tp.style = Paint.Style.FILL; tp.color = acc
                c.drawText(row, x, y, tp)
                c.restore()
            }
            before += row.length
        }
    }
}
