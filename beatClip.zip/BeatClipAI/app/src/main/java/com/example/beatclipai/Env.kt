package com.example.beatclipai

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

private fun pmod(a: Float, b: Float): Float { val r = a % b; return if (r < 0f) r + b else r }
private fun argb(v: Long): Int = v.toInt()

internal fun SceneRenderer.drawEnvironment(c: Canvas, env: BackgroundEnvironment, t: Float, m: Mo, bass: Float) {
    when (env) {
        BackgroundEnvironment.BEACH -> envBeach(c, t, m, bass)
        BackgroundEnvironment.FOREST -> envForest(c, t)
        BackgroundEnvironment.SPACE -> envSpace(c, t)
        BackgroundEnvironment.CITY -> envCity(c, t, m)
        BackgroundEnvironment.SUNSET -> envSunset(c, t, bass)
        BackgroundEnvironment.UNDERWATER -> envUnderwater(c, t)
        BackgroundEnvironment.NEON_GRID -> envNeon(c, t, m, bass)
        BackgroundEnvironment.FLOWER_FIELD -> envFlowers(c, t)
        BackgroundEnvironment.AURORA -> envAurora(c, t, m, bass)
        BackgroundEnvironment.BOKEH -> envBokeh(c, t, m)
        BackgroundEnvironment.ABSTRACT -> envAbstract(c, t, m)
    }
}

private fun SceneRenderer.tri(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, a: Float, col: Int) {
    path.reset(); path.moveTo(x1, y1); path.lineTo(x2, y2); path.lineTo(x3, y3); path.close()
    c.drawPath(path, fillP(col, a))
}

private fun SceneRenderer.envBeach(c: Canvas, t: Float, m: Mo, bass: Float) {
    val hz = H * 0.58f
    vgrad(c, 0f, hz, mix(argb(0xFF4FB3F6), sec, .3f), mix(argb(0xFFFFD9A0), acc, .3f))
    val sx = W * 0.75f; val sy = H * 0.2f
    glow(c, sx, sy, u * 0.7f, argb(0xFFFFF2A8), .6f)
    c.drawCircle(sx, sy, u * 0.085f * (1f + .05f * bass), fillP(argb(0xFFFFF6C0)))
    for (i in 0..2) cloud(c, pmod(t * (6 + 4 * i) + i * W * 0.4f, W + 300f) - 150f, H * (0.1f + 0.07f * i), u * (0.05f + 0.01f * i), .85f)
    vgrad(c, hz, H * 0.78f, mix(argb(0xFF2AA7E8), prim, .3f), mix(argb(0xFF0B4F8C), prim, .3f))
    for (k in 0..13) {
        val gx = sx + (hash(k) - .5f) * W * 0.3f * (1f + k / 14f)
        val gy = hz + (k + 1) * (H * 0.2f / 15f)
        c.drawLine(gx - u * 0.02f, gy, gx + u * 0.02f, gy, strokeP(WHITE, u * 0.004f, .55f * abs(sin(t * 3f + k))))
    }
    for (i in 0..5) wave(c, hz + H * 0.2f * (i + 1) / 7f, u * 0.007f * (1f + m.kick), u * (0.1f + 0.02f * i), t * 1.4f + i, WHITE, .45f, u * 0.004f)
    vgrad(c, H * 0.78f, H, mix(argb(0xFFF4DCA6), acc, .15f), mix(argb(0xFFD9B574), acc, .15f))
    wave(c, H * 0.78f, u * 0.01f, u * 0.2f, t, WHITE, .7f, u * 0.012f)
    for (side in intArrayOf(-1, 1)) {
        val bx = W * (if (side < 0) 0.07f else 0.93f)
        val tx = bx - side * u * 0.05f + sin(t + side) * u * 0.01f
        val ty = H * 0.5f
        path.reset(); path.moveTo(bx, H * 0.84f); path.quadTo(bx + side * u * 0.04f, H * 0.66f, tx, ty)
        c.drawPath(path, strokeP(argb(0xFF6B4423), u * 0.028f))
        for (k in 0..5) {
            val a = -PIF / 2f + (k - 2.5f) * 0.5f + sin(t * 1.5f + k) * 0.05f
            path.reset(); path.moveTo(tx, ty)
            path.quadTo(tx + cos(a) * u * 0.1f, ty + sin(a) * u * 0.12f - u * 0.04f, tx + cos(a) * u * 0.2f, ty + sin(a) * u * 0.2f + u * 0.05f)
            c.drawPath(path, strokeP(argb(0xFF2E9E5B), u * 0.022f))
        }
    }
}

private fun SceneRenderer.envForest(c: Canvas, t: Float) {
    vgrad(c, 0f, H, mix(argb(0xFF9BD9F0), sec, .3f), mix(argb(0xFFD8F3DC), acc, .3f))
    for (k in 0..4) {
        val x0 = W * (0.1f + 0.2f * k)
        val sw = sin(t * 0.4f + k) * u * 0.03f
        tri(c, x0, 0f, x0 + u * 0.1f + sw, H * 0.8f, x0 - u * 0.05f + sw, H * 0.8f, .10f, WHITE)
    }
    val bases = floatArrayOf(0.66f, 0.74f, 0.84f)
    val tws = floatArrayOf(0.16f, 0.21f, 0.28f)
    val cols = intArrayOf(argb(0xFF74C69D), argb(0xFF40916C), argb(0xFF1B4332))
    val spd = floatArrayOf(3f, 6f, 10f)
    for (layer in 0..2) {
        val col2 = mix(cols[layer], prim, .15f)
        val b = H * bases[layer]
        val w2 = u * tws[layer]
        val n = (W / (w2 * 0.8f)).toInt() + 3
        for (i in 0 until n) {
            val x = pmod(i * w2 * 0.8f - t * spd[layer] + layer * 40f, n * w2 * 0.8f) - w2
            c.drawRect(x - w2 * 0.06f, b, x + w2 * 0.06f, b + w2 * 0.5f, fillP(mix(argb(0xFF5C4033), col2, .3f)))
            for (tier in 0..2) {
                val th = w2 * (0.7f - tier * 0.1f)
                val ty = b - tier * w2 * 0.38f
                tri(c, x - w2 * (0.5f - tier * 0.1f), ty, x, ty - th, x + w2 * (0.5f - tier * 0.1f), ty, 1f, mix(col2, WHITE, .06f * tier))
            }
        }
        c.drawRect(0f, b + w2 * 0.4f, W, H, fillP(col2))
    }
    for (k in 0..2) c.drawRect(0f, H * (0.6f + 0.08f * k), W, H * (0.64f + 0.08f * k), fillP(WHITE, .05f))
    for (i in 0..23) {
        val x = W * hash(i * 3 + 1) + sin(t * .7f + i) * u * .05f
        val y = H * (.35f + .5f * hash(i * 5 + 2)) + cos(t * .9f + i) * u * .03f
        val a = .4f + .6f * abs(sin(t * 2f + i))
        glow(c, x, y, u * 0.04f, acc, a * .7f)
        c.drawCircle(x, y, u * 0.006f, fillP(WHITE, a))
    }
}

private fun SceneRenderer.envSpace(c: Canvas, t: Float) {
    vgrad(c, 0f, H, mix(argb(0xFF050018), prim, .15f), mix(argb(0xFF101040), sec, .3f))
    glow(c, W * .25f, H * .3f, u * .8f, prim, .3f); glow(c, W * .8f, H * .6f, u * .7f, sec, .28f); glow(c, W * .5f, H * .1f, u * .5f, acc, .15f)
    for (i in 0..119) {
        val x = W * hash(i * 3 + 1)
        val y = H * hash(i * 7 + 5)
        val tw = .4f + .6f * abs(sin(t * 1.7f + i))
        val r = u * (0.002f + 0.004f * hash(i + 3))
        if (i % 9 == 0) star4(c, x, y, r * 4f, WHITE, tw) else c.drawCircle(x, y, r, fillP(WHITE, tw))
    }
    val q = (t / 2f) % 1f
    if (q < 0.3f) {
        val k = q / 0.3f
        val x0 = W * (0.15f + 0.15f * (floor(t / 2f) % 5f))
        val y0 = H * 0.1f
        c.drawLine(x0 + k * u * .5f, y0 + k * u * .3f, x0 + k * u * .5f - u * .12f, y0 + k * u * .3f - u * .07f, strokeP(WHITE, u * .006f, 1f - k))
    }
    val px = W * .28f; val py = H * .24f; val pr = u * .15f
    val ring = RectF(px - pr * 1.9f, py - pr * .42f, px + pr * 1.9f, py + pr * .42f)
    c.save(); c.rotate(-18f, px, py); c.drawArc(ring, 180f, 180f, false, strokeP(mix(acc, WHITE, .3f), u * .014f, .8f)); c.restore()
    c.drawCircle(px, py, pr, fillP(mix(sec, argb(0xFF8888FF), .4f)))
    for (k in 0..2) c.drawArc(RectF(px - pr, py - pr * .8f + k * pr * .5f, px + pr, py + pr * .2f + k * pr * .5f), 200f, 140f, false, strokeP(mix(sec, WHITE, .35f), pr * .1f, .5f))
    c.drawCircle(px - pr * .3f, py - pr * .3f, pr * .5f, fillP(WHITE, .18f))
    c.save(); c.rotate(-18f, px, py); c.drawArc(ring, 0f, 180f, false, strokeP(mix(acc, WHITE, .3f), u * .014f)); c.restore()
    val moon = mix(argb(0xFF9AA0B5), sec, .3f)
    c.drawOval(RectF(-W * .3f, H * .84f, W * 1.3f, H * 1.6f), fillP(moon))
    for (i in 0..4) c.drawOval(RectF(W * (.05f + .2f * i), H * (.88f + .02f * (i % 2)), W * (.15f + .2f * i), H * (.91f + .02f * (i % 2))), fillP(mix(moon, OUT, .25f)))
}

private fun SceneRenderer.envCity(c: Canvas, t: Float, m: Mo) {
    vgrad(c, 0f, H, mix(argb(0xFF0B0B2B), prim, .25f), mix(argb(0xFF4B2A7C), sec, .4f))
    for (i in 0..39) c.drawCircle(W * hash(i * 3 + 1), H * .5f * hash(i * 5 + 2), u * .0025f, fillP(WHITE, .4f + .5f * abs(sin(t * 2f + i))))
    glow(c, W * .78f, H * .16f, u * .45f, argb(0xFFFFF6D0), .45f)
    c.drawCircle(W * .78f, H * .16f, u * .07f, fillP(argb(0xFFFFF6D0)))
    val hmin = floatArrayOf(.18f, .12f); val hmax = floatArrayOf(.36f, .30f)
    val bcol = intArrayOf(argb(0xFF2A1F5E), argb(0xFF120B2E)); val ncols = intArrayOf(8, 6)
    val half = m.beat / 2
    for (layer in 0..1) {
        val cols = ncols[layer]
        val bw = W / cols
        for (i in 0 until cols) {
            val bh = H * (hmin[layer] + (hmax[layer] - hmin[layer]) * hash(i * 3 + layer * 17))
            val x = i * bw - layer * bw * .25f
            val top = H * .88f - bh
            c.drawRect(x, top, x + bw * (if (layer == 1) .95f else .98f), H, fillP(mix(bcol[layer], prim, .12f)))
            val rows = (bh / (u * .05f)).toInt()
            val cols2 = if (layer == 1) 3 else 2
            for (r in 0 until rows) for (k in 0 until cols2) {
                if (((i * 31 + r * 17 + k * 13 + half) % (if (layer == 1) 4 else 5) + (if (layer == 1) 4 else 5)) % (if (layer == 1) 4 else 5) == 0) {
                    val wx = x + bw * (.14f + .28f * k)
                    val wy = top + u * .03f + r * u * .05f
                    c.drawRect(wx, wy, wx + bw * .14f, wy + u * .028f, fillP(if (layer == 1) acc else mix(acc, WHITE, .3f), if (layer == 1) .9f else .5f))
                }
            }
        }
    }
    c.drawRect(0f, H * .88f, W, H, fillP(mix(argb(0xFF15152B), prim, .1f)))
    for (k in 0..3) {
        val x = pmod(k * W * .3f - t * 30f, W + 100f) - 50f
        c.drawRect(x, H * .94f, x + W * .12f, H * .945f, fillP(WHITE, .5f))
    }
    for (k in 0..2) {
        val x = W * (.15f + .35f * k)
        c.drawLine(x, H * .88f, x, H * .74f, strokeP(argb(0xFF0A0A1A), u * .01f))
        glow(c, x, H * .74f, u * .12f, argb(0xFFFFE9A0), .6f)
    }
}

private fun SceneRenderer.envSunset(c: Canvas, t: Float, bass: Float) {
    vgrad(c, 0f, H * .4f, mix(argb(0xFF2B1055), sec, .4f), mix(argb(0xFF8E2A7A), prim, .4f))
    vgrad(c, H * .4f, H * .75f, mix(argb(0xFF8E2A7A), prim, .4f), mix(argb(0xFFFF9A3C), acc, .3f))
    val sx = W * .5f; val sy = H * .58f; val sr = u * .2f * (1f + .02f * bass)
    glow(c, sx, sy, u * .9f, argb(0xFFFFC04D), .55f)
    c.drawCircle(sx, sy, sr, fillP(mix(acc, argb(0xFFFFE066), .5f)))
    for (i in 0..3) {
        val x = pmod(t * (5 + i * 2) + i * W * .35f, W + 400f) - 200f
        c.drawOval(RectF(x, H * (.18f + .08f * i), x + 320f * u / 480f + 120f, H * (.2f + .08f * i)), fillP(mix(prim, argb(0xFFFFB347), .5f), .35f))
    }
    for (k in 0..3) {
        val bx = pmod(t * 40f + k * 90f, W + 100f) - 50f
        val by = H * .3f + sin(t + k) * u * .03f + k * u * .02f
        val fl = sin(t * 8f + k) * u * .01f
        path.reset(); path.moveTo(bx - u * .02f, by - fl); path.quadTo(bx - u * .01f, by - u * .01f + fl, bx, by); path.quadTo(bx + u * .01f, by - u * .01f + fl, bx + u * .02f, by - fl)
        c.drawPath(path, strokeP(argb(0xFF2B1055), u * .004f))
    }
    hills(c, H * .70f, u * .03f, u * .7f, 0f, mix(argb(0xFF5B2A86), prim, .25f), t * 4f)
    hills(c, H * .78f, u * .03f, u * .5f, 2f, mix(argb(0xFF3A1C71), sec, .2f), t * 8f)
    hills(c, H * .86f, u * .02f, u * .4f, 4f, mix(argb(0xFF22103F), sec, .2f), t * 14f)
}

private fun SceneRenderer.envUnderwater(c: Canvas, t: Float) {
    vgrad(c, 0f, H, mix(argb(0xFF2BB5C4), prim, .25f), mix(argb(0xFF03254C), sec, .3f))
    glow(c, W * .5f, -H * .05f, u * 1.1f, WHITE, .35f)
    for (k in 0..4) {
        val x0 = W * (.22f * k)
        val sw = sin(t * .6f + k) * u * .06f
        tri(c, x0, 0f, x0 + u * .14f + sw, H * .85f, x0 - u * .08f + sw, H * .85f, .07f, WHITE)
    }
    for (k in 0..4) {
        val fx = pmod(t * u * (.03f + .01f * k) + k * W * .3f, W + 200f) - 100f
        val fy = H * (.2f + .1f * k)
        c.drawOval(RectF(fx - u * .05f, fy - u * .02f, fx + u * .05f, fy + u * .02f), fillP(argb(0xFF03254C), .18f))
        tri(c, fx - u * .045f, fy, fx - u * .08f, fy - u * .025f, fx - u * .08f, fy + u * .025f, .18f, argb(0xFF03254C))
    }
    c.drawRect(0f, H * .9f, W, H, fillP(mix(argb(0xFFC2B280), acc, .1f)))
    wave(c, H * .9f, u * .008f, u * .12f, t * .5f, WHITE, .25f, u * .006f)
    for (i in 0..8) {
        val bx = W * (.03f + .94f * i / 8f)
        val ht = u * (.2f + .12f * hash(i + 30))
        val sw = sin(t * 1.3f + i) * u * .03f
        path.reset(); path.moveTo(bx, H * .92f); path.quadTo(bx + sw, H * .92f - ht * .5f, bx + sw * 1.6f, H * .92f - ht)
        c.drawPath(path, strokeP(mix(argb(0xFF2E9E5B), prim, .2f), u * .016f))
    }
    val coral = intArrayOf(argb(0xFFFF6B8B), argb(0xFFFFA94D), prim)
    for (i in 0..4) {
        val bx = W * (.12f + .2f * i)
        val col = coral[i % 3]
        for (k in 0..2) {
            val a = -PIF / 2f + (k - 1) * .6f
            val ex = bx + cos(a) * u * .1f
            val ey = H * .93f + sin(a) * u * .1f
            c.drawLine(bx, H * .93f, ex, ey, strokeP(col, u * .016f))
            c.drawCircle(ex, ey, u * .016f, fillP(col))
        }
    }
    for (i in 0..19) {
        val bx = W * hash(i * 3 + 2) + sin(t + i) * u * .03f
        val by = H - pmod(t * u * .13f * (.5f + hash(i + 7)) + hash(i * 5) * H, H * 1.1f)
        val r = u * (.008f + .012f * hash(i + 11))
        c.drawCircle(bx, by, r, strokeP(WHITE, u * .003f, .6f))
        c.drawCircle(bx - r * .3f, by - r * .3f, r * .25f, fillP(WHITE, .8f))
    }
}

private fun SceneRenderer.envNeon(c: Canvas, t: Float, m: Mo, bass: Float) {
    vgrad(c, 0f, H, argb(0xFF0A0014), mix(prim, argb(0xFF150030), .7f))
    val hz2 = H * .52f
    for (i in 0..49) c.drawCircle(W * hash(i * 3 + 1), hz2 * hash(i * 5 + 2), u * .002f, fillP(WHITE, .3f + .6f * abs(sin(t * 2f + i))))
    val sr = u * (.25f + .012f * bass)
    glow(c, W / 2f, hz2 - sr * .2f, u * .9f, prim, .45f + .2f * m.kick)
    c.drawCircle(W / 2f, hz2 - sr * .1f, sr, fillP(mix(acc, prim, .35f)))
    for (k in 0..5) {
        val y = hz2 - sr * .1f + k * sr * .14f - sr * .05f
        c.drawRect(W / 2f - sr, y, W / 2f + sr, y + sr * .02f * (k + 1), fillP(argb(0xFF0A0014)))
    }
    val mx = floatArrayOf(.12f, .3f, .72f, .9f)
    val mh = floatArrayOf(.1f, .16f, .14f, .09f)
    for (k in 0..3) {
        path.reset(); path.moveTo(W * (mx[k] - .16f), hz2); path.lineTo(W * mx[k], hz2 - H * mh[k]); path.lineTo(W * (mx[k] + .16f), hz2); path.close()
        c.drawPath(path, fillP(argb(0xFF0A0014))); c.drawPath(path, strokeP(acc, u * .005f, .9f))
    }
    c.drawRect(0f, hz2, W, H, fillP(argb(0xFF0A0014)))
    glow(c, W / 2f, hz2, u * .8f, prim, .25f + .25f * m.kick)
    for (i in -14..14) c.drawLine(W / 2f + i * u * .02f, hz2, W / 2f + i * u * .34f, H, strokeP(acc, u * .003f * (1f + m.kick), .85f))
    for (k in 0..9) {
        val fr = (k + (t * .6f) % 1f) / 10f
        val y = hz2 + (H - hz2) * fr * fr
        c.drawLine(0f, y, W, y, strokeP(prim, u * .004f * (1f + fr * 2f), .85f))
    }
}

private fun SceneRenderer.envFlowers(c: Canvas, t: Float) {
    vgrad(c, 0f, H * .6f, mix(argb(0xFF74C0FC), sec, .3f), mix(argb(0xFFFFE8F0), acc, .3f))
    glow(c, W * .2f, H * .12f, u * .6f, argb(0xFFFFF2A8), .55f)
    c.drawCircle(W * .2f, H * .12f, u * .07f, fillP(argb(0xFFFFF6C0)))
    for (i in 0..3) cloud(c, pmod(t * (5 + 3 * i) + i * W * .35f, W + 300f) - 150f, H * (.08f + .07f * i), u * (.05f + .01f * i), .9f)
    hills(c, H * .55f, u * .04f, u * .8f, 0f, mix(argb(0xFF9BE3A0), prim, .12f), t * 3f)
    hills(c, H * .63f, u * .035f, u * .6f, 2f, mix(argb(0xFF6FCF7A), prim, .12f), t * 6f)
    vgrad(c, H * .7f, H, mix(argb(0xFF4CAF50), prim, .12f), mix(argb(0xFF2F9E44), prim, .12f))
    val pal = intArrayOf(prim, sec, acc, WHITE)
    for (row in 0..2) {
        for (i in 0 until 18 - row * 3) {
            val fy = H * (.68f + .1f * row + .02f * hash(i + row * 7))
            val fx = W * hash(i * 7 + row * 3 + 5)
            val dep = .5f + .5f * row
            val r = u * (.012f + .016f * dep)
            val sw = sin(t * 2f + i + row) * u * .006f
            val col = pal[(i + row) % 4]
            c.drawLine(fx, fy + r * 3f, fx + sw, fy, strokeP(argb(0xFF2E7D32), u * .004f))
            for (k in 0..5) {
                val a = k * PIF / 3f
                c.drawCircle(fx + sw + cos(a) * r * 1.1f, fy + sin(a) * r * 1.1f, r * .75f, fillP(col))
            }
            c.drawCircle(fx + sw, fy, r * .7f, fillP(argb(0xFFFFE066)))
        }
    }
    for (i in 0..13) c.drawCircle(W * hash(i * 3 + 1) + sin(t + i) * u * .04f, H * (.3f + .4f * hash(i * 5 + 2)) + cos(t * .8f + i) * u * .03f, u * .004f, fillP(WHITE, .6f))
}

private fun SceneRenderer.envAurora(c: Canvas, t: Float, m: Mo, bass: Float) {
    vgrad(c, 0f, H, argb(0xFF02040F), mix(argb(0xFF0B1F3A), prim, .15f))
    for (i in 0..89) c.drawCircle(W * hash(i * 3 + 1), H * .7f * hash(i * 5 + 2), u * (.0015f + .002f * hash(i + 3)), fillP(WHITE, .35f + .6f * abs(sin(t * 1.5f + i))))
    val cols = intArrayOf(mix(argb(0xFF2BFF88), sec, .2f), mix(argb(0xFF35D0FF), sec, .3f), mix(prim, argb(0xFFB06BFF), .4f), mix(acc, argb(0xFF2BFF88), .5f))
    val bx = ArrayList<Float>()
    val by = ArrayList<Float>()
    for (band in 0..3) {
        bx.clear(); by.clear()
        path.reset()
        var x = -20f
        var first = true
        while (x <= W + 20f) {
            val ph1 = x / (u * (.5f + .12f * band)) * 2f * PIF + t * (.35f + .1f * band) + band * 1.7f
            val yt = H * (.16f + .06f * band) + sin(ph1) * u * .06f + sin(ph1 * 2.3f + t * .4f) * u * .02f
            val yb = yt + H * (.30f + .08f * sin(ph1 * .7f + t * .3f + band)) * (1f + .15f * m.kick)
            if (first) { path.moveTo(x, yt); first = false } else path.lineTo(x, yt)
            bx.add(x); by.add(yb)
            x += 14f
        }
        for (j in bx.indices.reversed()) path.lineTo(bx[j], by[j])
        path.close()
        val col = cols[band]
        val a0 = ColorUtils.setAlphaComponent(col, 0)
        val a1 = ColorUtils.setAlphaComponent(col, (255 * (.5f + .15f * bass)).toInt().coerceIn(0, 255))
        val a2 = ColorUtils.setAlphaComponent(col, (255 * .25f).toInt())
        p.reset(); p.isAntiAlias = true
        p.shader = LinearGradient(0f, H * .08f, 0f, H * .66f, intArrayOf(a0, a1, a2, a0), floatArrayOf(0f, 1f / 3f, 2f / 3f, 1f), Shader.TileMode.CLAMP)
        c.drawPath(path, p)
    }
    glow(c, W * .5f, H * .3f, u * .9f, cols[0], .12f + .1f * bass)
    hills(c, H * .78f, u * .05f, u * .9f, 1f, argb(0xFF05080F), t * 2f)
    hills(c, H * .84f, u * .04f, u * .6f, 3f, argb(0xFF03050A), t * 5f)
    vgrad(c, H * .88f, H, argb(0xFF0A1830), argb(0xFF02040F))
    for (k in 0..13) {
        val x = W * hash(k * 7 + 1)
        val y = H * (.9f + .09f * hash(k * 3))
        c.drawLine(x, y, x + u * .08f, y, strokeP(cols[k % 2], u * .004f, .18f + .12f * sin(t * 2f + k)))
    }
}

private fun SceneRenderer.envBokeh(c: Canvas, t: Float, m: Mo) {
    vgrad(c, 0f, H, mix(prim, Color.BLACK, .62f), mix(sec, Color.BLACK, .45f))
    for (k in 0..2) {
        val x0 = pmod(t * (14 + 6 * k) + k * W * .5f, W * 1.6f) - W * .3f
        path.reset(); path.moveTo(x0, 0f); path.lineTo(x0 + u * .25f, 0f); path.lineTo(x0 - u * .35f, H); path.lineTo(x0 - u * .6f, H); path.close()
        c.drawPath(path, fillP(WHITE, .045f))
    }
    val sizes = floatArrayOf(.09f, .055f, .03f)
    val speeds = floatArrayOf(.012f, .02f, .035f)
    val pal = intArrayOf(prim, sec, acc, WHITE)
    for (layer in 0..2) {
        val n = 9 + layer * 5
        for (i in 0 until n) {
            val sd = i + layer * 40
            val r = u * sizes[layer] * (.6f + .8f * hash(sd * 3 + 2)) * (1f + .12f * m.kick)
            val x = W * hash(sd * 5 + 1) + sin(t * .25f + sd) * u * .05f
            val y = H * 1.15f - pmod(t * u * speeds[layer] * (.5f + hash(sd + 7)) + hash(sd * 7 + 3) * H * 1.3f, H * 1.3f)
            val col = pal[sd % 4]
            val tw = .5f + .5f * sin(t * 1.2f + sd)
            glow(c, x, y, r * 1.5f, col, .22f * tw + .12f)
            c.drawCircle(x, y, r * .8f, fillP(col, .10f + .10f * tw))
            c.drawCircle(x, y, r * .8f, strokeP(WHITE, u * .003f, .10f + .12f * tw))
        }
    }
    glow(c, W * .1f, H * .1f, u * .8f, acc, .18f)
    glow(c, W * .9f, H * .85f, u * .8f, prim, .2f)
}

private fun SceneRenderer.envAbstract(c: Canvas, t: Float, m: Mo) {
    vgrad(c, 0f, H, mix(prim, Color.BLACK, .55f), mix(sec, Color.BLACK, .55f))
    val pal = intArrayOf(prim, sec, acc)
    for (i in 0..5) {
        val x = W * (.5f + .4f * sin(t * .4f + i * 1.7f))
        val y = H * (.5f + .4f * cos(t * .3f + i * 2.3f))
        val r = u * (.35f + .05f * i) * (1f + .1f * m.kick)
        glow(c, x, y, r, pal[i % 3], .5f)
    }
    for (k in 0..3) {
        val rr = (m.ph + k) / 4f
        c.drawCircle(W / 2f, H * .45f, u * (.1f + rr * .8f), strokeP(WHITE, u * .006f, .5f * (1f - rr)))
    }
    val pal4 = intArrayOf(prim, sec, acc, WHITE)
    for (i in 0..17) {
        val x = W * hash(i * 3 + 1)
        val y = H - pmod(t * u * .05f * (.5f + hash(i + 7)) + hash(i * 5) * H, H * 1.1f)
        val r = u * (.01f + .015f * hash(i + 2))
        val col = pal4[i % 4]
        when (i % 3) {
            0 -> c.drawCircle(x, y, r, fillP(col, .7f))
            1 -> tri(c, x, y - r, x + r, y + r, x - r, y + r, .7f, col)
            else -> c.drawRect(x - r, y - r, x + r, y + r, fillP(col, .7f))
        }
    }
}
