package com.example.beatclipai

import kotlin.math.abs

class LyricLine(val start: Float, val end: Float, val text: String)

object LyricsParser {
    private val lineRe = Regex("""^\s*((?:\[\d{1,3}:\d{2}(?:[.:]\d{1,3})?\])+)\s*(.*)$""")
    private val tagRe = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]""")
    private val sectionRe = Regex("""^\s*\[[^\]]*\]\s*$""")

    /**
     * Accepts either timed lyrics (.lrc style: "[01:23.50] words") or plain lines.
     * Plain lines are spread evenly over the video and snapped to the nearest beat.
     */
    fun parse(raw: String, durationSec: Float, beats: BeatMap?): List<LyricLine> {
        if (raw.isBlank()) return emptyList()
        val lines = raw.lines()
        val timed = ArrayList<Pair<Float, String>>()
        for (l in lines) {
            val m = lineRe.matchEntire(l) ?: continue
            val text = m.groupValues[2].trim()
            for (tm in tagRe.findAll(m.groupValues[1])) {
                val mins = tm.groupValues[1].toInt()
                val secs = tm.groupValues[2].toInt()
                val frac = tm.groupValues[3].let { if (it.isEmpty()) 0f else "0.$it".toFloat() }
                timed.add((mins * 60 + secs + frac) to text)
            }
        }
        if (timed.isNotEmpty()) {
            timed.sortBy { it.first }
            val out = ArrayList<LyricLine>()
            for (i in timed.indices) {
                val st = timed[i].first
                val en = if (i + 1 < timed.size) timed[i + 1].first else minOf(st + 4f, maxOf(st + 1f, durationSec))
                if (timed[i].second.isNotBlank() && st < durationSec) out.add(LyricLine(st, en, timed[i].second))
            }
            return out
        }
        val texts = lines.map { it.trim() }.filter { it.isNotEmpty() && !sectionRe.matches(it) }
        if (texts.isEmpty()) return emptyList()
        val n = texts.size
        val starts = FloatArray(n)
        for (i in 0 until n) {
            var st = i * durationSec / n
            if (beats != null && beats.beats.isNotEmpty()) {
                var best = beats.beats[0]
                for (b in beats.beats) if (abs(b - st) < abs(best - st)) best = b
                st = best
            }
            if (i > 0 && st <= starts[i - 1]) st = starts[i - 1] + 0.5f
            starts[i] = st
        }
        return List(n) { i ->
            val en = if (i + 1 < n) starts[i + 1] else durationSec
            LyricLine(starts[i], maxOf(en, starts[i] + 0.5f), texts[i])
        }
    }
}
