package com.example.beatclipai

import android.content.ActivityNotFoundException
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import java.io.File
import java.util.Locale

private val KidColors = lightColorScheme(
    primary = Color(0xFF7C4DFF),
    secondary = Color(0xFFFF6FB5),
    tertiary = Color(0xFFFFB300),
    background = Color(0xFFFFF8E1),
    surface = Color(0xFFFFFDF5),
    primaryContainer = Color(0xFFE8DEFF)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = KidColors) {
                Surface(modifier = Modifier.fillMaxSize()) { BeatClipApp() }
            }
        }
    }
}

private fun safeStart(context: Context, intent: Intent, failMessage: String) {
    try { context.startActivity(intent) } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, failMessage, Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BeatClipApp(vm: MusicVideoViewModel = viewModel()) {
    val state by vm.uiState.collectAsState()
    var gateAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    Scaffold(topBar = { TopAppBar(title = { Text("🎵 BeatClip Kids", fontWeight = FontWeight.Bold) }) }) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = state.activeTab) {
                Tab(selected = state.activeTab == 0, onClick = { vm.setTab(0) }, text = { Text("🎬 Studio") })
                Tab(selected = state.activeTab == 1, onClick = { vm.setTab(1) }, text = { Text("📦 Pictures (${state.savedOfflineAssets.size})") })
            }
            if (state.activeTab == 0) StudioTab(vm, state) { action -> gateAction = action }
            else PicturesTab(vm, state) { action -> gateAction = action }
        }
    }

    if (state.showDownloadDialog) {
        DownloadQualityPopup(
            durationMs = vm.effectiveDurationMs(),
            selectedQuality = state.selectedQuality,
            isWorking = state.isWorking,
            onSelectQuality = vm::setQuality,
            onSaveToGallery = { vm.exportVideo(saveToDownloadsFolder = false) },
            onDownloadToFolder = { vm.exportVideo(saveToDownloadsFolder = true) },
            onDismiss = vm::closeDownloadPopup
        )
    }
    gateAction?.let { action ->
        GrownUpGate(onPass = { gateAction = null; action() }, onCancel = { gateAction = null })
    }
}

/** A tiny maths question so little ones can't leave the app or use the network by accident. */
@Composable
fun GrownUpGate(onPass: () -> Unit, onCancel: () -> Unit) {
    val a = remember { (3..9).random() }
    val b = remember { (3..9).random() }
    var answer by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("👨‍👩‍👧 Ask a grown-up") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("What is $a + $b ?")
                OutlinedTextField(
                    value = answer, onValueChange = { answer = it.take(3); wrong = false },
                    singleLine = true, isError = wrong,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                if (wrong) Text("Not quite, try again.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            Button(onClick = { if (answer.trim().toIntOrNull() == a + b) onPass() else wrong = true }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

@Composable
private fun BigTitle(text: String) = Text(text, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudioTab(vm: MusicVideoViewModel, state: StudioUiState, askGrownUp: (() -> Unit) -> Unit) {
    val context = LocalContext.current
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            vm.onAudioPicked(uri)
        }
    }
    val lyricsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) vm.onLyricsFilePicked(uri)
    }
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(6)) { uris ->
        if (uris.isNotEmpty()) vm.onCustomBackgroundsPicked(uris)
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        BigTitle("1️⃣ Your song 🎵")
        Text(state.audioLabel, style = MaterialTheme.typography.bodyMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { audioPicker.launch(arrayOf("audio/*")) }, enabled = !state.isWorking, modifier = Modifier.weight(1f).height(52.dp)) { Text("🎧 Pick a song") }
            FilledTonalButton(onClick = { vm.generateSynthBeat() }, enabled = !state.isWorking, modifier = Modifier.weight(1f).height(52.dp)) { Text("🥁 Make a beat") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = state.songTitle, onValueChange = vm::updateSongTitle, label = { Text("Song name") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(value = state.artistName, onValueChange = vm::updateArtistName, label = { Text("Singer") }, singleLine = true, modifier = Modifier.weight(1f))
        }

        HorizontalDivider()
        BigTitle("2️⃣ Song words 📝")
        Text("Type or paste the words, one line per row. Timed .lrc files work too!", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(
            value = state.lyricsText, onValueChange = vm::updateLyrics,
            label = { Text("Words of the song") }, minLines = 3, maxLines = 6,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedButton(onClick = { lyricsPicker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("📄 Load a words file") }

        HorizontalDivider()
        BigTitle("3️⃣ Pick a world 🌍")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            BackgroundEnvironment.entries.forEach { env ->
                FilterChip(
                    selected = state.customBackgroundUris.isEmpty() && state.selectedOfflineAssetIds.isEmpty() && state.environment == env,
                    onClick = {
                        vm.clearCustomBackgrounds()
                        state.selectedOfflineAssetIds.toList().forEach { vm.toggleOfflineAsset(it) }
                        vm.setEnvironment(env)
                    },
                    label = { Text(env.label) }
                )
            }
        }
        if (state.savedOfflineAssets.isNotEmpty()) {
            Text("My saved pictures (tap to use):", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                state.savedOfflineAssets.forEach { asset ->
                    FilterChip(
                        selected = state.selectedOfflineAssetIds.contains(asset.id),
                        onClick = { vm.toggleOfflineAsset(asset.id) },
                        label = { Text(asset.title.take(18)) }
                    )
                }
            }
        }
        OutlinedButton(
            onClick = { bgPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) },
            enabled = !state.isWorking, modifier = Modifier.fillMaxWidth().height(48.dp)
        ) { Text(if (state.customBackgroundUris.isEmpty()) "📱 Use pictures from my phone" else "📱 ${state.customBackgroundUris.size} picked") }

        BigTitle("4️⃣ Who dances? 🐰🐼🐸")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            AnimatedSubject.entries.forEach { sub ->
                FilterChip(selected = state.selectedSubjects.contains(sub), onClick = { vm.toggleSubject(sub) }, label = { Text(sub.label) })
            }
        }
        BigTitle("🕺 Dance style")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            DanceStyle.entries.forEach { st ->
                FilterChip(selected = state.danceStyle == st, onClick = { vm.setDanceStyle(st) }, label = { Text(st.label) })
            }
        }

        HorizontalDivider()
        BigTitle("5️⃣ Colours 🎨")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            ColorPalettePreset.entries.filter { it != ColorPalettePreset.CUSTOM }.forEach { preset ->
                FilterChip(selected = state.colorScheme.preset == preset, onClick = { vm.selectColorPreset(preset) }, label = { Text(preset.label) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(28.dp).clip(CircleShape).background(Color(state.colorScheme.primaryColor())))
            Box(Modifier.size(28.dp).clip(CircleShape).background(Color(state.colorScheme.secondaryColor())))
            Box(Modifier.size(28.dp).clip(CircleShape).background(Color(state.colorScheme.accentColor())))
            Text("My colours", style = MaterialTheme.typography.labelMedium)
        }
        Text("Main colour", style = MaterialTheme.typography.labelSmall)
        Slider(value = state.colorScheme.primaryHue, onValueChange = { vm.updateColors(primaryHue = it) }, valueRange = 0f..360f)
        Text("Second colour", style = MaterialTheme.typography.labelSmall)
        Slider(value = state.colorScheme.secondaryHue, onValueChange = { vm.updateColors(secondaryHue = it) }, valueRange = 0f..360f)
        Text("Sparkle colour", style = MaterialTheme.typography.labelSmall)
        Slider(value = state.colorScheme.accentHue, onValueChange = { vm.updateColors(accentHue = it) }, valueRange = 0f..360f)
        Text("Brightness", style = MaterialTheme.typography.labelSmall)
        Slider(value = state.colorScheme.vibrancy, onValueChange = { vm.updateColors(vibrancy = it) }, valueRange = 0.25f..1.0f)

        HorizontalDivider()
        BigTitle("6️⃣ Shape & length 📏")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = state.isPortrait, onClick = { vm.setPortrait(true) }, label = { Text("📱 Tall") })
            FilterChip(selected = !state.isPortrait, onClick = { vm.setPortrait(false) }, label = { Text("🖥️ Wide") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = state.useFullAudioDuration, onClick = { vm.setFullSongMode() }, label = { Text("Whole song") })
            listOf(15, 30, 60).forEach { sec ->
                FilterChip(selected = !state.useFullAudioDuration && state.previewSeconds == sec, onClick = { vm.setPreviewSeconds(sec) }, label = { Text("${sec}s") })
            }
        }

        HorizontalDivider()
        BigTitle("7️⃣ Preview & touch 👆")
        PreviewPanel(vm, state)

        Button(
            onClick = { vm.openDownloadPopup() }, enabled = !state.isWorking,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text(if (state.isWorking) "Working… ⏳" else "🎬 Make my music video!", style = MaterialTheme.typography.titleMedium) }

        if (state.isWorking) {
            LinearProgressIndicator(progress = { (state.progressPercent / 100f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            Text("${state.progressPercent}%", style = MaterialTheme.typography.labelMedium)
        }
        Text(state.statusText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)

        state.exportedVideoUri?.let { videoUri ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val view = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(videoUri, "video/mp4")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        safeStart(context, view, "No video player found")
                    },
                    modifier = Modifier.weight(1f).height(52.dp)
                ) { Icon(Icons.Default.PlayArrow, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Watch") }
                OutlinedButton(
                    onClick = {
                        askGrownUp {
                            val share = Intent(Intent.ACTION_SEND).apply {
                                type = "video/mp4"
                                putExtra(Intent.EXTRA_STREAM, videoUri)
                                clipData = ClipData.newRawUri(null, videoUri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            safeStart(context, Intent.createChooser(share, "Share Music Video"), "Nothing to share with")
                        }
                    },
                    modifier = Modifier.weight(1f).height(52.dp)
                ) { Icon(Icons.Default.Share, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Share (grown-up)") }
            }
        }
    }
}


private class PlayerHolder { var player: PcmPlayer? = null }

/** Live preview in time with the music. Touch it and everyone points at your finger while they dance. */
@Composable
fun PreviewPanel(vm: MusicVideoViewModel, state: StudioUiState) {
    val context = LocalContext.current
    val holder = remember { PlayerHolder() }
    var playing by remember { mutableStateOf(false) }
    var frame by remember { mutableStateOf(0) }
    val pw = if (state.isPortrait) 270 else 480
    val ph = if (state.isPortrait) 480 else 270
    val bitmap = remember(pw, ph) { Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888) }
    val canvas = remember(bitmap) { AndroidCanvas(bitmap) }
    val key = listOf(
        state.environment, state.selectedSubjects, state.colorScheme, state.danceStyle, state.lyricsText,
        state.songTitle, state.artistName, state.customBackgroundUris, state.selectedOfflineAssetIds,
        state.audioLabel, state.useFullAudioDuration, state.previewSeconds
    )
    val scene = remember(pw, key) { vm.buildScene(pw, ph) }
    DisposableEffect(scene) { onDispose { BackdropLoader.release(scene.backdrops) } }
    val beats = vm.previewBeats()
    val renderer = remember(scene, beats) { if (beats != null) SceneRenderer(pw, ph, scene, beats) else null }
    val limitSec = minOf(vm.effectiveDurationMs() / 1000f, (vm.previewPcm()?.durationMs ?: 0L) / 1000f)
    val rec = state.recordTouches

    DisposableEffect(Unit) { onDispose { holder.player?.stop(); holder.player = null } }

    // a still frame while stopped
    LaunchedEffect(renderer, playing) {
        if (!playing && renderer != null) { renderer.draw(canvas, 2.0f); frame++ }
    }
    // live frames while playing, driven by the real audio position
    LaunchedEffect(playing, renderer) {
        if (playing && renderer != null) {
            while (true) {
                withFrameNanos { }
                val pl = holder.player ?: break
                val t = pl.positionSec()
                renderer.draw(canvas, t)
                frame++
                if (t >= limitSec) { pl.stop(); holder.player = null; playing = false; break }
            }
        }
    }

    Text("Touch the screen while it plays - everyone points at your finger! 👆", style = MaterialTheme.typography.bodySmall)
    Canvas(
        modifier = Modifier
            .fillMaxWidth(if (state.isPortrait) 0.6f else 1f)
            .aspectRatio(pw / ph.toFloat())
            .clip(MaterialTheme.shapes.medium)
            .pointerInput(renderer, rec) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    val r = renderer
                    val ts = ArrayList<Float>()
                    val xs = ArrayList<Float>()
                    val ys = ArrayList<Float>()
                    fun update(px: Float, py: Float) {
                        val nx = (px / size.width).coerceIn(0f, 1f)
                        val ny = (py / size.height).coerceIn(0f, 1f)
                        r?.livePointer = floatArrayOf(nx, ny)
                        val pl = holder.player
                        if (rec && pl != null) { ts.add(pl.positionSec()); xs.add(nx); ys.add(ny) }
                        if (r != null && pl == null) { r.draw(canvas, 2.0f); frame++ }
                    }
                    update(down.position.x, down.position.y)
                    do {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull()
                        if (ch != null && ch.pressed) update(ch.position.x, ch.position.y)
                        ev.changes.forEach { it.consume() }
                    } while (ev.changes.any { it.pressed })
                    r?.livePointer = null
                    if (ts.isNotEmpty()) vm.addTouchStroke(TouchStroke(ts.toFloatArray(), xs.toFloatArray(), ys.toFloatArray()))
                    if (r != null && holder.player == null) { r.draw(canvas, 2.0f); frame++ }
                }
            }
    ) {
        val tick = frame
        if (tick >= 0) drawImage(bitmap.asImageBitmap(), dstSize = IntSize(size.width.toInt(), size.height.toInt()))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
            onClick = {
                if (!playing) {
                    val audio = vm.previewPcm()
                    if (audio == null) {
                        Toast.makeText(context, "Pick a song or make a beat first! 🎵", Toast.LENGTH_SHORT).show()
                    } else {
                        val pl = PcmPlayer(audio)
                        holder.player = pl
                        pl.start()
                        playing = true
                    }
                } else {
                    holder.player?.stop(); holder.player = null; playing = false
                }
            },
            modifier = Modifier.weight(1f).height(48.dp)
        ) { Text(if (playing) "⏹ Stop" else "▶ Play preview") }
        OutlinedButton(onClick = { vm.clearTouches() }, modifier = Modifier.weight(1f).height(48.dp)) { Text("🧹 Clear pointing (${state.touchCount})") }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Switch(checked = state.recordTouches, onCheckedChange = vm::setRecordTouches)
        Text("Keep my pointing in the video", style = MaterialTheme.typography.bodyMedium)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PicturesTab(vm: MusicVideoViewModel, state: StudioUiState, askGrownUp: (() -> Unit) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        BigTitle("✈️ BeatClip works offline")
        Text(
            "No internet is used while you make videos. Once a month a grown-up can connect to Wi-Fi " +
                "to get a fresh batch of safe pictures. Everything saved stays on this phone.",
            style = MaterialTheme.typography.bodyMedium
        )
        Text(state.nextImportText, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)

        BigTitle("Pick topics for the next import")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            ImportTopic.entries.forEach { t ->
                FilterChip(selected = t in state.selectedImportTopics, onClick = { vm.toggleImportTopic(t) }, label = { Text(t.label) })
            }
        }
        Button(
            onClick = { askGrownUp { vm.importNow() } },
            enabled = state.canStartImport && !state.isImporting && state.selectedImportTopics.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text(if (state.isImporting) "Importing… 📥" else "📥 Get new pictures (grown-up)") }
        if (state.isImporting) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        if (state.importStatus.isNotBlank()) Text(state.importStatus, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)

        HorizontalDivider()
        BigTitle("My saved pictures (${state.savedOfflineAssets.size})")
        if (state.savedOfflineAssets.isEmpty()) {
            Text("Nothing saved yet. The built-in worlds in the Studio are always ready! 🌈", style = MaterialTheme.typography.bodySmall)
        } else {
            state.savedOfflineAssets.forEach { asset ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(model = File(asset.filePath), contentDescription = asset.title, contentScale = ContentScale.Crop, modifier = Modifier.size(64.dp).clip(MaterialTheme.shapes.medium))
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(asset.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                            Text(asset.credit, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = {
                            if (!state.selectedOfflineAssetIds.contains(asset.id)) vm.toggleOfflineAsset(asset.id)
                            vm.setTab(0)
                        }) { Text("Use") }
                        IconButton(onClick = { vm.deleteOfflineAsset(asset.id) }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                    }
                }
            }
        }
    }
}

@Composable
fun DownloadQualityPopup(
    durationMs: Long,
    selectedQuality: VideoQuality,
    isWorking: Boolean,
    onSelectQuality: (VideoQuality) -> Unit,
    onSaveToGallery: () -> Unit,
    onDownloadToFolder: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🎬 Pick video quality") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                VideoQuality.entries.forEach { q ->
                    val isSelected = q == selectedQuality
                    val mb = String.format(Locale.US, "%.1f MB", q.estimateSizeMb(durationMs))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                shape = MaterialTheme.shapes.medium
                            )
                            .clickable { onSelectQuality(q) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = isSelected, onClick = { onSelectQuality(q) })
                        Spacer(Modifier.width(6.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(q.label, fontWeight = FontWeight.SemiBold)
                            Text("${q.desc} • about $mb", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onSaveToGallery, enabled = !isWorking) { Text("💾 Save (Movies)") }
                Button(onClick = onDownloadToFolder, enabled = !isWorking) { Text("⬇️ Download") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
